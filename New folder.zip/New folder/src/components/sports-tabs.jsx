import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import backgroundImage from '../assets/Images/sports-tabs-background.jpg'
import '../assets/style.css'


// const categories = ['Soccer', 'Baseball and Softball', 'Tennis and Pickleball', 'Basketball', 'Football', 'Gymnastics' ];

// const services = {
    // 'Soccer': [
    //     { description: 'Boosts agility, endurance, coordination, and tactical awareness.', },
    // ],
    // 'Baseball and Softball': [
    //     { description: 'Boosts agility, endurance, coordination, and tactical awareness.', },
    // ],
    // 'Tennis and Pickleball': [
    //     { description: 'Boosts agility, endurance, coordination, and tactical awareness.', },
    // ],
    // 'Basketball': [
    //     { description: 'Boosts agility, endurance, coordination, and tactical awareness.', },
    // ],
    // 'Football': [
    //     { description: 'Boosts agility, endurance, coordination, and tactical awareness.', },
    // ],
    // 'Gymnastics': [
    //     { description: 'Boosts agility, endurance, coordination, and tactical awareness.', },
    // ]
// };


const SportsTabSection = ({ services}) => {
    const [activeCategory, setActiveCategory] = useState('');

    const [activeCategoryIndex, setActiveCategoryIndex] = useState(0);
    

    useEffect(() => {
    if (services?.sections?.length > 0) {
        setActiveCategory(services.sections[0]._id);
        setActiveCategoryIndex(0);
    }
}, [services]);


    return (
        <>
            <div className="tabs sports_tabs text-white overflow-hidden" id='conditions' style={{ backgroundImage: `url(${services?.sections[activeCategoryIndex]?.image})` }}>
                <div className="container-full">
                    <div className="d-flex grid-items flex-wrap">
                        {/* Left Tabs */}
                        <div className="left-block grid-item d-pt-100 pt-60 d-pb-120 pb-40">
                            {/* <h6 class="mb-15 fw-300">SPORTS</h6>
                            <h2 class="mb-40 d-fs-36 fs-26">that may benefit</h2> */}

                            <h6 class="mb-15 fw-300">{services?.title}</h6>
                            <h2 class="mb-40 d-fs-36 fs-26">{services?.description}</h2>

                            <div className="d-flex flex-column align-start gap-15 vertical_tab_buttons d-ps-40 ps-30 position-relative">
                                {services?.sections?.map((category, index) => (
                                    <button key={index} onClick={() => {
                                        setActiveCategory(category._id);

                                        setActiveCategoryIndex(index)
                                    }} className={`position-relative button d-flex gap-10 align-center ${activeCategory === category._id ? 'active' : ''}`} >
                                        {category?.title}
                                    </button>

                                ))}
                            </div>
                        </div>
                        {/* Right Services */}
                        <div className="right-block grid-item d-pt-200 d-ps-80 p-30">
                            <div className="grid-items">
                                {/* {services[activeCategory].map((service, index) => (
                                    <div key={index} className="grid-item">
                                        <div className='summary-block'>
                                            <p className="d-fs-22 fs-16 max-w-400">{service.description}</p>
                                        </div>
                                    </div>
                                ))} */}
                                    <div  className="grid-item">
                                        <div className='summary-block'>
                                            <p className="d-fs-22 fs-16 max-w-400">{services?.sections[activeCategoryIndex]?.description}</p>
                                        </div>
                                    </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default SportsTabSection;
