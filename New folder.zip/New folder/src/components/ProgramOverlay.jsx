import React, { useEffect, useState } from 'react';
import '../assets/style.css';
import ArrowWhite from '../assets/icons/white-arrow-right.svg'

const ProgramOverlay = ({ program, onClose, onSelect }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (program) {
      setIsVisible(true); // trigger show animation
    }
  }, [program]);

  if (!program) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      setIsVisible(false); // trigger hide animation
      setTimeout(onClose, 300); // wait for animation to finish
    }
  };

  return (
    <div
      className={`overlay-backdrop d-flex justify-end ${isVisible ? 'overlay-open' : 'overlay-close'}`}
      onClick={handleBackdropClick}
    >
      <div className="overlay-content-box text-white" onClick={(e) => e.stopPropagation()} >
        <div className="header-block position-relative bg-size-cover bg-no-repeat bg-position-center pt-100 pb-40 d-px-50 px-20" style={{ backgroundImage: `url(${program.image})` }} >
          <button className="overlay-close-btn" onClick={() => { setIsVisible(false); setTimeout(onClose, 300); }}>×</button>
          <div className="text-block position-relative">
            <h2 className="mb-10 capitalize helvetica-font d-fs-26 fs-22 fw-300">
              {program?.title}
            </h2>
            <p className="helvetica-font fs-16 fw-300 letter-spacing-001">
              {program?.program_title}
            </p>
          </div>
        </div>

        <div className="content-block d-flex flex-wrap justify-between align-start gap-40 py-40 d-px-50 px-20">
          <div className="text-block max-w-700">
            <p className='helvetica-font fs-14 fw-300'>
              {/* The Eat Well specialty program is a cutting-edge, clinically grounded approach to
              nutrition that goes beyond conventional personalization. Rooted in the science of
              precision nutrition, this program combines molecular, physiological, and phenotypic
              data to craft highly targeted nutritional strategies tailored to each individual’s
              unique biology. Using tools like advanced lab testing, body composition analysis,
              metabolic profiling, and AI-enhanced interpretation, Eat Well identifies how your body
              responds to specific foods, nutrients, and lifestyle patterns. Whether you're
              optimizing energy, managing chronic inflammation, improving gut health, or enhancing
              performance, Eat Well delivers nutrition plans based on mechanistic insights, not
              guesswork. By stratifying individuals into clinically meaningful "metabotypes," the
              program offers scalable yet deeply individualized care that evolves as your biology
              changes, helping you eat smarter, live longer, and feel your best. */}

              {program?.description}
            </p>
          </div>
          <button className="button button-primary select-button d-flex align-center gap-10" onClick={onSelect}>
            SELECT THIS <img src={ArrowWhite} alt="" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProgramOverlay;
