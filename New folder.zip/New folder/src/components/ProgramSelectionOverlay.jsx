// import React, { useState, useEffect } from 'react';
// import '../assets/style.css';
// import Image1 from '../assets/Images/tab_item1.jpg';
// import Image2 from '../assets/Images/tab_item2.jpg';
// import Image3 from '../assets/Images/tab_item3.jpg';
// import Image4 from '../assets/Images/tab_item4.jpg';
// import ArrowWhite from '../assets/icons/white-arrow-right.svg'

// const ProgramSelectionOverlay = ({ program, programs = [], onClose }) => {
//   const tabs = ['specialized programs', 'create your own', 'about you'];
//   const [activeTab, setActiveTab] = useState(tabs[0]);
//   const [isVisible, setIsVisible] = useState(false);
//   const [selectedPrograms, setSelectedPrograms] = useState([]);

//   console.log('program', program)
//   const categoryServices = [
//     { title: 'Functional Movement', description: '', image: Image1 },
//     { title: 'Functional Medicine', description: '', image: Image2 },
//     { title: 'Health Coaching', description: '', image: Image3 },
//     { title: 'Coaching for HER', description: '', image: Image4 },
//     { title: 'Coaching for HIM', description: '', image: Image2 },
//     { title: 'Personal Training', description: '', image: Image1 },
//     { title: 'Functional Immunology', description: '', image: Image1 },
//     { title: 'Functional Endocrinology', description: '', image: Image2 },
//   ];

//   // Dummy all programs list — you should pass this from props or manage globally
//   // const allPrograms = [...programs, ...categoryServices];  // Just using the passed one for now

//   const allPrograms = [...programs];  // Just using the passed one for now

//   console.log('allPrograms', allPrograms)
//   console.log('categoryServices', categoryServices)
//   useEffect(() => {
//     if (program) {
//       setIsVisible(true);
//       setSelectedPrograms([program]); // set clicked program as selected
//     }
//   }, [program]);

//   // Handle close animations
//   const handleBackdropClick = (e) => {
//     if (e.target === e.currentTarget) {
//       setIsVisible(false);
//       setTimeout(onClose, 300);
//     }
//   };

//   const isProgramSelected = (prog) => {
//     return selectedPrograms.some(p => p.title === prog.title);
//   };

//   const toggleSelectProgram = (prog) => {
//     if (isProgramSelected(prog)) {
//       // Remove it
//       setSelectedPrograms(prev => prev.filter(p => p.title !== prog.title));
//     } else {
//       // Add it
//       setSelectedPrograms(prev => [...prev, prog]);
//     }
//   };

//   const handleClose = () => {
//     setIsVisible(false);
//     setTimeout(onClose, 300);
//   };

//   // Remove program from selected list
//   const handleRemove = (indexToRemove) => {
//     setSelectedPrograms((prev) => prev.filter((_, index) => index !== indexToRemove));
//   };

//   if (!program) return null;

//   return (
//     <div className="overlay-backdrop d-flex justify-end overlay-open text-white" onClick={handleBackdropClick} >
//       <div className="overlay-content-box text-white" onClick={(e) => e.stopPropagation()}>

//         {/* Header */}
//         <div className="d-flex flex-wrap justify-between gap-30 py-30 d-px-50 px-20">
//           <div className="left-block">
//             <h6 className='mb-10 fw-500 font-primary'>PERSONALIZED</h6>
//             <h2 className='d-fs-26 fs-20'>create your own program</h2>
//           </div>
//           <div className="right-block">
//             <button className="button button-primary select-button d-flex align-center gap-10">NEXT <img src={ArrowWhite} alt="" /></button>
//           </div>
//         </div>

//         {/* Selected Programs */}
//         <div className="selected-programs py-30 d-px-50 px-20">
//           <h6 className='fw-400 fs-10 uppercase mb-20'>SELECTED</h6>
//           <div className="grid-items d-grid d-col-gap-45 col-gap-20 row-gap-25">
//             {selectedPrograms.map((prog, index) => (
//               <div className="grid-item" key={index}>
//                 <div className="image-box p-10 d-flex gap-10 align-center">
//                   <div className="image-block d-flex">
//                     <img src={prog?.featuredImage} alt={prog?.program_title} className='object-cover object-position-center' />
//                   </div>
//                   <div className="text-block d-flex flex-column justify-center align-start gap-5 position-relative pe-30">
//                     <h5 className='letter-spacing-0'>{prog?.program_title}</h5>
//                     <button className='p-0 fs-12 line-height-180 font-secondry fw-300 letter-spacing-001 bg-transparent color-white'>learn more</button>
//                     <button onClick={() => handleRemove(index)} className="remove-btn p-0 position-absolute top-10 line-height-100">
//                       <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
//                         <path d="M11.1197 0.512964L7.14219 4.49044L3.16472 0.512964C2.67665 0.0248945 1.88502 0.0248946 1.39695 0.512964L0.513065 1.39685C0.0249955 1.88492 0.0249954 2.67654 0.513065 3.16461L4.49054 7.14209L0.513065 11.1196C0.0249954 11.6076 0.0249955 12.3993 0.513065 12.8873L1.39695 13.7712C1.88502 14.2593 2.67665 14.2593 3.16472 13.7712L7.14219 9.79374L11.1197 13.7712C11.6077 14.2593 12.3994 14.2593 12.8874 13.7712L13.7713 12.8873C14.2594 12.3993 14.2594 11.6076 13.7713 11.1196L9.79384 7.14209L13.7713 3.16461C14.2594 2.67654 14.2594 1.88492 13.7713 1.39685L12.8874 0.512964C12.3994 0.0248946 11.6077 0.0248939 11.1197 0.512964Z" fill="white" />
//                       </svg>
//                     </button>
//                   </div>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>

//         {/* Tabs */}
//         <div className="layover_tabs ">
//           <div className="overflow-x-auto  mb-30">
//             <div className="tab-bar d-flex d-gap-40 gap-10 d-px-50 px-20">
//               {tabs.map((tab) => (
//                 <div
//                   key={tab}
//                   className={`tab p-15 helvetica-font d-fs-18 fs-16 ${activeTab === tab ? 'active' : ''}`}
//                   onClick={() => setActiveTab(tab)}
//                 >
//                   {tab}
//                 </div>
//               ))}
//             </div>
//           </div>

//           {/* Tab Content */}
//           <div className="tab-content d-px-50 px-20 pb-40">
//             {activeTab === 'specialized programs' && (
//               <div>
//                 <div className="grid-items d-grid d-col-gap-45 col-gap-20 row-gap-25">
//                   {allPrograms?.filter((p) => !isProgramSelected(p)).map((prog, index) => (
//                     <div className="grid-item" key={index} onClick={() => toggleSelectProgram(prog)} style={{ cursor: 'pointer' }} >
//                       <div className="image-box p-10 d-flex gap-10 align-center">
//                         <div className="image-block d-flex">
//                           <img src={prog.featuredImage} alt={prog?.program_title} className="object-cover object-position-center" />
//                         </div>
//                         <div className="text-block d-flex flex-column justify-center align-start gap-5 position-relative pe-30">
//                           <h5 className="letter-spacing-0">{prog?.program_title}</h5>
//                           <button className="p-0 fs-12 line-height-180 font-secondry fw-300 letter-spacing-001 bg-transparent color-white" onClick={(e) => e.stopPropagation()} >
//                             learn more
//                           </button>
//                         </div>
//                       </div>
//                     </div>
//                   ))}

//                 </div>
//               </div>
//             )}

//             {activeTab === 'create your own' && (
//               <div>
//                 <h4 className="mb-10">Create Your Own</h4>
//                 <p>Content for create your own tab goes here...</p>
//               </div>
//             )}

//             {activeTab === 'about you' && (
//               <div>
//                 <h4 className="mb-10">About You</h4>
//                 <p>Content for about you tab goes here...</p>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ProgramSelectionOverlay;















import React, { useState, useEffect } from 'react';
import '../assets/style.css';
import Image1 from '../assets/Images/tab_item1.jpg';
import Image2 from '../assets/Images/tab_item2.jpg';
import Image3 from '../assets/Images/tab_item3.jpg';
import Image4 from '../assets/Images/tab_item4.jpg';
import ArrowWhite from '../assets/icons/white-arrow-right.svg'

const ProgramSelectionOverlay = ({ program, programs = [], onClose }) => {
  const tabs = ['specialized programs', 'create your own', 'about you'];
  const [activeTab, setActiveTab] = useState(tabs[0]);
  const [isVisible, setIsVisible] = useState(false);
  const [selectedPrograms, setSelectedPrograms] = useState([]);

  // LocalStorage key for selected programs
  const STORAGE_KEY = 'selectedPrograms';

  console.log('program', program)
  const categoryServices = [
    { title: 'Functional Movement', description: '', image: Image1 },
    { title: 'Functional Medicine', description: '', image: Image2 },
    { title: 'Health Coaching', description: '', image: Image3 },
    { title: 'Coaching for HER', description: '', image: Image4 },
    { title: 'Coaching for HIM', description: '', image: Image2 },
    { title: 'Personal Training', description: '', image: Image1 },
    { title: 'Functional Immunology', description: '', image: Image1 },
    { title: 'Functional Endocrinology', description: '', image: Image2 },
  ];

  const allPrograms = [...programs];

  console.log('allPrograms', allPrograms)
  console.log('categoryServices', categoryServices)

  // Load selected programs from localStorage
  const loadSelectedPrograms = () => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (error) {
      console.error('Error loading selected programs from localStorage:', error);
    }
    return [];
  };

  // Save selected programs to localStorage
  const saveSelectedPrograms = (programs) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(programs));
    } catch (error) {
      console.error('Error saving selected programs to localStorage:', error);
    }
  };

  useEffect(() => {
    // Load previously selected programs from localStorage
    const savedPrograms = loadSelectedPrograms();
    
    if (program) {
      setIsVisible(true);
      
      // Check if the current program is already in saved programs
      const isAlreadySelected = savedPrograms.some(p => p.title === program.title || p.program_title === program.program_title);
      
      if (!isAlreadySelected) {
        // Add current program to saved programs
        const updatedPrograms = [...savedPrograms, program];
        setSelectedPrograms(updatedPrograms);
        saveSelectedPrograms(updatedPrograms);
      } else {
        // Just set the saved programs
        setSelectedPrograms(savedPrograms);
      }
    } else {
      // If no program prop, just load saved programs
      setSelectedPrograms(savedPrograms);
    }
  }, [program]);

  // Handle close animations
  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      setIsVisible(false);
      setTimeout(onClose, 300);
    }
  };

  const isProgramSelected = (prog) => {
    return selectedPrograms.some(p => 
      (p.title && prog.title && p.title === prog.title) || 
      (p.program_title && prog.program_title && p.program_title === prog.program_title)
    );
  };

  const toggleSelectProgram = (prog) => {
    let updatedPrograms;
    
    if (isProgramSelected(prog)) {
      // Remove it
      updatedPrograms = selectedPrograms.filter(p => 
        !((p.title && prog.title && p.title === prog.title) || 
          (p.program_title && prog.program_title && p.program_title === prog.program_title))
      );
    } else {
      // Add it
      updatedPrograms = [...selectedPrograms, prog];
    }
    
    setSelectedPrograms(updatedPrograms);
    saveSelectedPrograms(updatedPrograms);
  };

  const handleClose = () => {
    setIsVisible(false);
    setTimeout(onClose, 300);
  };

  // Remove program from selected list
  const handleRemove = (indexToRemove) => {
    const updatedPrograms = selectedPrograms.filter((_, index) => index !== indexToRemove);
    setSelectedPrograms(updatedPrograms);
    saveSelectedPrograms(updatedPrograms);
  };

  // Clear all selected programs (optional utility function)
  const clearAllSelected = () => {
    setSelectedPrograms([]);
    saveSelectedPrograms([]);
  };

  if (!program && selectedPrograms.length === 0) return null;

  return (
    <div className="overlay-backdrop d-flex justify-end overlay-open text-white" onClick={handleBackdropClick} >
      <div className="overlay-content-box text-white" onClick={(e) => e.stopPropagation()}>

        {/* Header */}
        <div className="d-flex flex-wrap justify-between gap-30 py-30 d-px-50 px-20">
          <div className="left-block">
            <h6 className='mb-10 fw-500 font-primary'>PERSONALIZED</h6>
            <h2 className='d-fs-26 fs-20'>create your own program</h2>
          </div>
          <div className="right-block">
            <button className="button button-primary select-button d-flex align-center gap-10">NEXT <img src={ArrowWhite} alt="" /></button>
          </div>
        </div>

        {/* Selected Programs */}
        {selectedPrograms.length > 0 && (
          <div className="selected-programs py-30 d-px-50 px-20">
            <div className="d-flex justify-between align-center mb-20">
              <h6 className='fw-400 fs-10 uppercase'>SELECTED ({selectedPrograms.length})</h6>
              <button 
                onClick={clearAllSelected}
                className="p-0 fs-10 fw-300 bg-transparent color-white text-decoration-underline"
              >
                Clear All
              </button>
            </div>
            <div className="grid-items d-grid d-col-gap-45 col-gap-20 row-gap-25">
              {selectedPrograms.map((prog, index) => (
                <div className="grid-item" key={index}>
                  <div className="image-box p-10 d-flex gap-10 align-center">
                    <div className="image-block d-flex">
                      <img src={prog?.featuredImage} alt={prog?.program_title || prog?.title} className='object-cover object-position-center' />
                    </div>
                    <div className="text-block d-flex flex-column justify-center align-start gap-5 position-relative pe-30">
                      <h5 className='letter-spacing-0'>{prog?.program_title || prog?.title}</h5>
                      <button className='p-0 fs-12 line-height-180 font-secondry fw-300 letter-spacing-001 bg-transparent color-white'>learn more</button>
                      <button onClick={() => handleRemove(index)} className="remove-btn p-0 position-absolute top-10 line-height-100">
                        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M11.1197 0.512964L7.14219 4.49044L3.16472 0.512964C2.67665 0.0248945 1.88502 0.0248946 1.39695 0.512964L0.513065 1.39685C0.0249955 1.88492 0.0249954 2.67654 0.513065 3.16461L4.49054 7.14209L0.513065 11.1196C0.0249954 11.6076 0.0249955 12.3993 0.513065 12.8873L1.39695 13.7712C1.88502 14.2593 2.67665 14.2593 3.16472 13.7712L7.14219 9.79374L11.1197 13.7712C11.6077 14.2593 12.3994 14.2593 12.8874 13.7712L13.7713 12.8873C14.2594 12.3993 14.2594 11.6076 13.7713 11.1196L9.79384 7.14209L13.7713 3.16461C14.2594 2.67654 14.2594 1.88492 13.7713 1.39685L12.8874 0.512964C12.3994 0.0248946 11.6077 0.0248939 11.1197 0.512964Z" fill="white" />
                        </svg>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="layover_tabs ">
          <div className="overflow-x-auto  mb-30">
            <div className="tab-bar d-flex d-gap-40 gap-10 d-px-50 px-20">
              {tabs.map((tab) => (
                <div
                  key={tab}
                  className={`tab p-15 helvetica-font d-fs-18 fs-16 ${activeTab === tab ? 'active' : ''}`}
                  onClick={() => setActiveTab(tab)}
                >
                  {tab}
                </div>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="tab-content d-px-50 px-20 pb-40">
            {activeTab === 'specialized programs' && (
              <div>
                <div className="grid-items d-grid d-col-gap-45 col-gap-20 row-gap-25">
                  {allPrograms?.filter((p) => !isProgramSelected(p)).map((prog, index) => (
                    <div className="grid-item" key={index} onClick={() => toggleSelectProgram(prog)} style={{ cursor: 'pointer' }} >
                      <div className="image-box p-10 d-flex gap-10 align-center">
                        <div className="image-block d-flex">
                          <img src={prog.featuredImage} alt={prog?.program_title} className="object-cover object-position-center" />
                        </div>
                        <div className="text-block d-flex flex-column justify-center align-start gap-5 position-relative pe-30">
                          <h5 className="letter-spacing-0">{prog?.program_title}</h5>
                          <button className="p-0 fs-12 line-height-180 font-secondry fw-300 letter-spacing-001 bg-transparent color-white" onClick={(e) => e.stopPropagation()} >
                            learn more
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'create your own' && (
              <div>
                <h4 className="mb-10">Create Your Own</h4>
                <p>Content for create your own tab goes here...</p>
              </div>
            )}

            {activeTab === 'about you' && (
              <div>
                <h4 className="mb-10">About You</h4>
                <p>Content for about you tab goes here...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgramSelectionOverlay;