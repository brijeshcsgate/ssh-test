import { useState } from 'react';
import serviceRichtext1 from '../assets/Images/service_richtext1.jpg';
import serviceRichtext2 from '../assets/Images/service_richtext2.jpg';

const AthleticDevelopment = ({ services, galleryImages }) => {
    const [activeTab, setActiveTab] = useState(0);

    return (
        <div className="athletic-development text-black d-py-100 py-60 d-px-20" id='services'>
            <div className="container">
                {/* Header */}
                <div className="header-block text-center">
                    {/* <h6 className="fs-14 fw-400 pb-20">PRODUCTS AND SERVICES</h6>
                    <h2>for Athletic Development</h2> */}

                    <h6 className="fs-14 fw-400 pb-20">{services?.title}</h6>
                    <h2>{services?.description}</h2>

                </div>

                {/* Tab Buttons */}
                {/* <div className="tab-buttons d-flex justify-center gap-10 d-pt-60 pt-30">
                    <button className={`button rounded-full uppercase  ${activeTab === 'services' ? 'active' : ''}`} onClick={() => setActiveTab('services')} >
                        Services
                    </button>
                    <button className={`button rounded-full uppercase  ${activeTab === 'products' ? 'active' : ''}`} onClick={() => setActiveTab('products')} >
                        Products
                    </button>
                </div> */}
                <div className="tab-buttons d-flex justify-center gap-10 d-pt-60 pt-30">
                    {services?.sections[0]?.subtabs?.map((tab, index) => (
                        <button
                            key={index}
                            className={`button rounded-full uppercase ${activeTab === index ? "active" : ""}`}
                            onClick={() => setActiveTab(index)}
                        >
                            {tab?.title}
                        </button>
                    ))}
                </div>
                {/* Tabs Content */}
                <div className="tabs_content">
                    {/* ✅ Services Content */}
                    {/* {activeTab === 'services' && ( */}
                    <div className="services_content">
                        {/* Section 1 */}
                        {/* <div className="grid-items d-grid d-column-2 d-gap-50 gap-30 d-pt-80 pt-40">
                                <div className="grid-item">
                                    <div className="summary-block">
                                        <h6 className="fs-16 fw-400 pb-30 uppercase ">Initial Evaluation</h6>
                                        <p>Our initial evaluation is a one-on-one client consultation, health appraisal, movement and fitness assessment, and physical examination used to inform a new patient’s exercise, nutrition, and lifestyle prescription. We'll discuss your health history, fitness experience, and what you hope to achieve. After the completion of the patient’s personal training sessions and/or programming, the patient will also perform regularly scheduled re-evaluations in the form of interim and summative assessments for a pre- and post- program comparison.  For all assessments, the patient should arrive with clothing and footwear appropriate for exercise. We’ll answer any questions and set a game plan for your fitness journey. For youth athletes, both parents are strongly encouraged to attend.</p>
                                    </div>
                                </div>
                                <div className="grid-item">
                                    <div className="summary-block">
                                        <h6 className="fs-16 fw-400 pb-30 uppercase ">Training Sessions</h6>
                                        <p>Our in-person athletic development sessions at our local gym partners provide expert, hands-on coaching in a dynamic and motivating environment. The first training session will serve as a workout introduction where you’ll go through a light, guided workout so we can see how you move and further evaluate the perfect starting point for you. Every ongoing session is part of a long-term program, tailored to your goals—whether you're building strength, improving mobility, enhancing endurance, or recovering from injury. With close supervision, real-time feedback, and access to premium equipment, you'll train with precision and purpose. We emphasize functional movement, proper form, and progressive programming to ensure each workout supports long-term performance, injury prevention, and confidence in your body’s capabilities. It’s not just about working out—it’s about training smart, moving well, and building a stronger version of you.</p>
                                    </div>
                                </div>
                            </div> */}
                        <div className="grid-items d-grid d-column-2 d-gap-50 gap-30 d-pt-80 pt-40">
                            {services?.sections[0]?.subtabs[activeTab]?.sections?.slice(0, 2)?.map((summary, idx) => (
                                <div key={idx} className="grid-item">
                                    <div className="summary-block">
                                        <h6 className="fs-16 fw-400 pb-30 uppercase">{summary?.title}</h6>
                                        <p>{summary?.description}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                        {/* Images */}
                        {/* galleryImages */}
                        {/* {(activeTab === 0) && (services?.sections[0]?.subtabs[activeTab]?.sections?.length >= 2) ?
                            <div className="images-block d-flex gap-10 d-pt-60 pt-40">
                                <div className="small_image d-flex">
                                    <img src={galleryImages[0]} alt="Service Small" />
                                </div>
                                <div className="large_image d-flex">
                                    <img src={serviceRichtext1} alt="Service Large" />
                                </div>
                            </div> : <></>} */}
                        {(activeTab === 0) && (services?.sections[0]?.subtabs[activeTab]?.sections?.length >= 2) ?

                            <div className="images-block d-flex gap-10 d-pt-60 pt-40">
                                {galleryImages?.map((image, idx) => (
                                    <div
                                        key={idx}
                                        className={`${idx % 2 === 0 ? "large_image" : "small_image"} d-flex`}
                                    >
                                        <img src={image} alt='a' />
                                    </div>
                                ))}
                            </div>
                            : <></>}
                        {/* Section 2 */}
                        {/* <div className="grid-items d-grid d-column-2 d-gap-50 gap-30 d-pt-80 pt-40">
                                <div className="grid-item">
                                    <div className="summary-block">
                                        <h6 className="fs-16 fw-400 pb-30 uppercase ">Private On-Location Personal Training</h6>
                                        <p>Our private on-location athletic development training brings the training and the expertise to you. Whether at your home, on the field, or another preferred space, we deliver high-level, customized training in a setting that’s convenient, comfortable, and 100% focused on you. With all the benefits of individualized coaching and none of the commute or distractions, this service is ideal for those who value privacy, flexibility, and efficiency. We bring everything needed for a comprehensive session, from functional equipment to expert guidance, helping you reach your goals safely and effectively—wherever life takes you. Private small group training is also offered as a bespoke service for friends and teammates who prefer the benefits of training and competing together.</p>
                                    </div>
                                </div>
                                <div className="grid-item">
                                    <div className="summary-block">
                                        <h6 className="fs-16 fw-400 pb-30 uppercase ">Sports Nutrition Consultation</h6>
                                        <p>Our sports nutrition consultation is designed to fuel your performance, accelerate recovery, and optimize body composition through personalized, evidence-based strategies. Whether you're a competitive athlete, weekend warrior, or fitness enthusiast, we tailor your nutritional plan to your specific goals, training demands, and physiology. Using data from body composition analysis, performance metrics, and lifestyle habits, we address nutrient timing, macronutrient balance, hydration, supplementation, and recovery fueling. We also evaluate gut health, inflammation, and metabolic efficiency to ensure your body is absorbing and utilizing nutrients effectively. The result? A sustainable, science-backed plan that helps you train harder, recover faster, and perform at your peak—on and off the field. </p>
                                    </div>
                                </div>
                            </div> */}


                        <div className="grid-items d-grid d-column-2 d-gap-50 gap-30 d-pt-80 pt-40">
                            {services?.sections[0]?.subtabs[activeTab]?.sections?.slice(2)?.map((summary, idx) => (
                                <div key={idx} className="grid-item">
                                    <div className="summary-block">
                                        <h6 className="fs-16 fw-400 pb-30 uppercase">{summary?.title}</h6>
                                        <p>{summary?.description}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                    {/* )} */}

                    {/* ✅ Products Content */}
                    {/* {activeTab === 'products' && (
                        <div className="products_content">
                            <div className="grid-items d-grid d-column-2 d-gap-50 gap-30 d-pt-80 pt-40">
                                <div className="grid-item">
                                    <div className="summary-block">
                                        <h6 className="fs-16 fw-400 pb-30 uppercase  ">Genova NutrEval</h6>
                                        <p>The NutrEval is both a blood and urine profile that evaluates over 125 biomarkers and assesses the body's functional need for 40 antioxidants, vitamins, minerals, essential fatty acids, amino acids, digestive support, and other select nutrients. Personalized recommendations for nutrients are determined by using an algorithm based on your patient's test findings. Functional pillars with a built-in scoring system guide the need for therapeutic support in areas of methylation, toxic exposure, mitochondrial dysfunction, fatty acid imbalances, and oxidative stress. The NutrEval Plasma and NutrEval FMV (first morning void) differ based on which sample type is used to measure amino acids, plasma or urine.</p>
                                    </div>
                                </div>
                                <div className="grid-item">
                                    <div className="summary-block">
                                        <h6 className="fs-16 fw-400 pb-30 uppercase ">MaxGen “The Works” Genetic Methylation and MTHFR Test</h6>
                                        <p>This panel tests approximately 180 of the most researched and most important genetic variants, providing insights into crucial aspects of your health. The recommendations in the TheWorks Panel are designed to help offset genetic tendencies in metabolic pathways that are important to the function of our cells and bodies. Those individuals who wish to optimize and improve their diet, lifestyle, nutrient intake, environmental exposures, and much more, “The Works” is MaxGen’s most advanced and popular genetics test. All MaxGen Labs reports are designed to safely recommend custom diet, vitamin supplementation and lifestyle recommendations. They do not diagnose or treat disease; however, the recommendations have helped thousands of people improve their health with many reporting significant improvements in certain conditions.</p>
                                    </div>
                                </div>
                            </div>
                            <div className="grid-items d-grid d-column-2 d-gap-50 gap-30 d-pt-80 pt-40">
                                <div className="grid-item">
                                    <div className="summary-block">
                                        <h6 className="fs-16 fw-400 pb-30 uppercase">WHOOP Wearable Biometrics</h6>
                                        <p>Build better habits with personalized guidance. WHOOP analyzes millions of data points 24/7, translating insights about your body into clear recommendations that help you build better habits, make smarter choices, and optimize your health. No other wearable gives you a more comprehensive view of your health and fitness – and tells you how to improve it.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )} */}
                </div>
            </div>
        </div>
    );
};

export default AthleticDevelopment;
