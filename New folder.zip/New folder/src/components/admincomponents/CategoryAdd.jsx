import React, { useState } from 'react';
import { Save } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import config from '../../config';
import axios from "axios";

const CategoryAdd = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    description: ''
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Generic input change handler
  const handleInputChange = (field, value) => {
    console.log('Input change - Field:', field, 'Value:', value);

    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Clear any existing error for this field
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  // Form validation
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Category name is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Submit form
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await axios.post(
        `${config.BASE_URL}/api/admin/categories`,
        {
          name: formData.name.trim(),
          description: formData.description.trim()
        },
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json",
          }
        }
      );

      console.log('Category add response:', response);

      if (response.status === 200 || response.status === 201) {
        // Success - navigate back to dashboard or categories list
        const token = localStorage.getItem("token");
        if (token) {
          navigate("/admin/category");
        } else {
          navigate("/admin/login");
        }
      }
    } catch (err) {
      console.error("Error adding category:", err);

      let errorMessage = "Failed to add category";

      if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      } else if (err.response?.status === 400) {
        errorMessage = "Invalid category data provided";
      } else if (err.response?.status === 409) {
        errorMessage = "Category name already exists";
      } else if (err.response?.status === 401) {
        errorMessage = "Unauthorized. Please login again.";
        navigate("/admin/login");
        return;
      }

      setErrors({ submit: errorMessage });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="dashboard">
      <div className="container">
        <div className="main-section">
          <div className="form-header">
            <h1 className="form-title">Add New Category</h1>
            <button
              onClick={() => navigate(-1)}
              className="back-button"
            >
              Go Back
            </button>
          </div>

          <div className="form-container">
            <form onSubmit={handleSubmit} className="category-form">
              {/* Category Information */}
              <div className="form-section">
                <h2 className="section-heading">Category Information</h2>

                <div className="form-fields">
                  {/* Category Name */}
                  <div className="form-field">
                    <label className="form-label">
                      Category Name *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      className={`form-input ${errors.name ? 'form-input-error' : ''}`}
                      placeholder="Enter category name"
                      required
                      disabled={isSubmitting}
                    />
                    {errors.name && (
                      <p className="error-text">{errors.name}</p>
                    )}
                  </div>

                  {/* Category Description */}
                  <div className="form-field">
                    <label className="form-label">
                      Description
                    </label>
                    <textarea
                      value={formData.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                      rows="4"
                      className="form-textarea"
                      placeholder="Enter category description (optional)"
                      disabled={isSubmitting}
                    />
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="submit-section">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="submit-button"
                >
                  <Save className="icon" />
                  {isSubmitting ? 'Adding Category...' : 'Add Category'}
                </button>
              </div>

              {errors.submit && (
                <div className="error-message">
                  {errors.submit}
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryAdd;