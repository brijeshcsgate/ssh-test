// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { useParams, useNavigate, Link } from "react-router-dom";
// import config from '../../config';

// function ProjectDetails() {
//     const { id } = useParams();
//     const [project, setProject] = useState(null);
//     const [loading, setLoading] = useState(true);
//     const [error, setError] = useState('');
//     const [activeTab, setActiveTab] = useState(0);
//     const navigate = useNavigate();

//     const fetchProjectDetails = async () => {
//         try {
//             const response = await axios.get(`${config.BASE_URL}/api/admin/get-project/${id}`, { withCredentials: true });
//             setProject(response.data);
//         } catch (err) {
//             setError('Failed to fetch project details');
//         } finally {
//             setLoading(false);
//         }
//     }

//     useEffect(() => {
//         fetchProjectDetails();
//     }, [id]);

//     const handleDelete = async () => {
//         try {
//             await axios.delete(`${config.BASE_URL}/api/admin/delete-project/${id}`, { withCredentials: true });
//             // Navigate back to the project list or show a success message
//             navigate('/admin/programs');
//         } catch (err) {
//             setError('Failed to delete the project');
//         }
//     };

//     // Helper function to get correct image URL
//     const getImageUrl = (imagePath) => {
//         if (!imagePath) return '';
//         // If it's already a full URL, return as is
//         if (imagePath.startsWith('http')) {
//             return imagePath;
//         }
//         // If it starts with /uploads, construct the full URL
//         if (imagePath.startsWith('/uploads')) {
//             return `${config.BASE_URL}${imagePath}`;
//         }
//         // If it's just the filename, construct the full URL
//         return `${config.BASE_URL}/uploads/${imagePath}`;
//     };

//     if (loading) return (
//         <div className="loading-container">
//             <p className="loading-text">Loading...</p>
//         </div>
//     );

//     if (error) return (
//         <div className="error-container">
//             <p className="error-text">{error}</p>
//         </div>
//     );

//     if (!project) return (
//         <div className="no-project-container">
//             <p className="no-project-text">No project found</p>
//         </div>
//     );

//     return (
//         <div className="dashboard">
//             <div className="container">
//                 <div className="main-section">
//                     <div className="project-header">
//                         <h1 className="project-title">Program Details</h1>
//                         <button
//                             onClick={() => navigate(-1)}
//                             className="back-button"
//                         >
//                             Go Back
//                         </button>
//                     </div>

//                     <div className="project-info-grid">
//                         <div className="project-info-section">
//                             <div className="info-card">
//                                 <h2 className="info-label">Banner Title</h2>
//                                 <p className="info-value">{project.program_title}</p>
//                             </div>

//                             <div className="info-card">
//                                 <h2 className="info-label">Banner Description</h2>
//                                 <p className="info-value">{project.banner_description || 'No banner description'}</p>
//                             </div>

//                             <div className="info-card">
//                                 <h2 className="info-label">Is Featured</h2>
//                                 <p className="info-value">{project.isFetured === 'true' ? 'Yes' : 'No'}</p>
//                             </div>

//                             {project.featuredImage && (
//                                 <div className="featured-image-section">
//                                     <h3 className="section-title">Featured Image</h3>
//                                     <div className="image-container">
//                                         <img
//                                             src={getImageUrl(project.featuredImage)}
//                                             alt="Featured"
//                                             className="featured-image"
//                                             onError={(e) => {
//                                                 console.error('Image failed to load:', project.featuredImage);
//                                                 e.target.style.display = 'none';
//                                             }}
//                                         />
//                                     </div>
//                                 </div>
//                             )}
//                         </div>

//                         <div className="project-info-section">
//                             <div className="info-card">
//                                 <h2 className="info-label">Title</h2>
//                                 <p className="info-value">{project.title}</p>
//                             </div>

//                             <div className="info-card">
//                                 <h2 className="info-label">Description</h2>
//                                 <p className="info-value">{project.description}</p>
//                             </div>
//                             <div className="info-card">
//                                 <h2 className="info-label">Category</h2>
//                                 <p className="info-value">{project.category || 'Not specified'}</p>
//                             </div>
//                             <div className="info-card">
//                                 <h2 className="info-label">Slug</h2>
//                                 <p className="info-value">{project.slug}</p>
//                             </div>
//                         </div>
//                     </div>

//                     {/* Images Section */}
//                     <div className="gallery-section">
//                         <h2 className="section-title">Gallery Images</h2>

//                         {project.galleryImages && project.galleryImages.length > 0 && (
//                             <div className="gallery-grid">
//                                 {project.galleryImages.map((image, index) => (
//                                     <div key={index} className="gallery-item">
//                                         <img
//                                             src={getImageUrl(image)}
//                                             alt={`Gallery image ${index + 1}`}
//                                             className="gallery-image"
//                                             onError={(e) => {
//                                                 console.error('Gallery image failed to load:', image);
//                                                 e.target.style.display = 'none';
//                                             }}
//                                         />
//                                     </div>
//                                 ))}
//                             </div>
//                         )}
//                     </div>

//                     {project.tabs && project.tabs.length > 0 && (
//                         <div className="tabs-section">
//                             <h2 className="section-title">Program Tabs</h2>

//                             <div className="tabs-navigation">
//                                 {project.tabs.map((tab, tabIndex) => (
//                                     <button
//                                         key={tab.id}
//                                         onClick={() => setActiveTab(tabIndex)}
//                                         className={`tab-button ${activeTab === tabIndex ? 'active' : ''}`}
//                                     >
//                                         {tab.tabTitle}
//                                     </button>
//                                 ))}
//                             </div>

//                             {project.tabs[activeTab] && (
//                                 <div className="tab-content">
//                                     <div className="tab-header">
//                                         <h3 className="tab-title">
//                                             {project.tabs[activeTab].title}
//                                         </h3>
//                                         <p className="tab-description">{project.tabs[activeTab].description}</p>
//                                     </div>
//                                     {project.tabs[activeTab].sections && project.tabs[activeTab].sections.length > 0 && (
//                                         <div className="sections-container">
//                                             <h4 className="sections-title">Sections</h4>
//                                             <div className="sections-list">
//                                                 {project.tabs[activeTab].sections.map((section, sectionIndex) => (
//                                                     <div key={sectionIndex} className="section-item">
//                                                         <h5 className="section-name">{section.title}</h5>
//                                                         <p className="section-description">{section.description}</p>

//                                                         {section.image && (
//                                                             <div className="section-image-container">
//                                                                 <img
//                                                                     src={getImageUrl(section.image)}
//                                                                     alt={section.title}
//                                                                     className="section-image"
//                                                                     onError={(e) => {
//                                                                         console.error('Section image failed to load:', section.image);
//                                                                         e.target.style.display = 'none';
//                                                                     }}
//                                                                 />
//                                                             </div>
//                                                         )}

//                                                         {section.subtabs && section.subtabs.length > 0 && (
//                                                             <div className="subtabs-container">
//                                                                 <h6 className="subtabs-title">Subtabs</h6>
//                                                                 <div className="subtabs-list">
//                                                                     {section.subtabs.map((subtab, subtabIndex) => (
//                                                                         <div key={subtab.id} className="subtab-item">
//                                                                             <h7 className="subtab-name">{subtab.tabTitle}</h7>
//                                                                             <p className="subtab-title">{subtab.title}</p>
//                                                                             <p className="subtab-description">{subtab.description}</p>

//                                                                             {subtab.sections && subtab.sections.length > 0 && (
//                                                                                 <div className="subsections-container">
//                                                                                     <h8 className="subsections-title">Sections</h8>
//                                                                                     <div className="subsections-list">
//                                                                                         {subtab.sections.map((subSection, subSectionIndex) => (
//                                                                                             <div key={subSection.id} className="subsection-item">
//                                                                                                 <h9 className="subsection-name">{subSection.title}</h9>
//                                                                                                 <p className="subsection-description">{subSection.description}</p>
//                                                                                                 {subSection.image && (
//                                                                                                     <img
//                                                                                                         src={getImageUrl(subSection.image)}
//                                                                                                         alt={subSection.title}
//                                                                                                         className="subsection-image"
//                                                                                                         onError={(e) => {
//                                                                                                             console.error('Subsection image failed to load:', subSection.image);
//                                                                                                             e.target.style.display = 'none';
//                                                                                                         }}
//                                                                                                     />
//                                                                                                 )}
//                                                                                             </div>
//                                                                                         ))}
//                                                                                     </div>
//                                                                                 </div>
//                                                                             )}
//                                                                         </div>
//                                                                     ))}
//                                                                 </div>
//                                                             </div>
//                                                         )}
//                                                     </div>
//                                                 ))}
//                                             </div>
//                                         </div>
//                                     )}
//                                 </div>
//                             )}
//                         </div>
//                     )}

//                     <div className="action-buttons">
//                         <button
//                             onClick={handleDelete}
//                             className="delete-button"
//                         >
//                             Delete
//                         </button>
//                         <Link
//                             to={`/admin/update-program/${project._id}`}
//                             className="edit-button"
//                         >
//                             Edit
//                         </Link>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// }

// export default ProjectDetails;














import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useNavigate, Link } from "react-router-dom";
import config from '../../config';

function ProjectDetails() {
    const { id } = useParams();
    const [project, setProject] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [activeTab, setActiveTab] = useState(0);
    const navigate = useNavigate();

    const fetchProjectDetails = async () => {
        try {
            const response = await axios.get(`${config.BASE_URL}/api/admin/get-project/${id}`, { withCredentials: true });
            setProject(response.data);
        } catch (err) {
            setError('Failed to fetch project details');
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        fetchProjectDetails();
    }, [id]);

    const handleDelete = async () => {
        try {
            await axios.delete(`${config.BASE_URL}/api/admin/delete-project/${id}`, { withCredentials: true });
            navigate('/admin/programs');
        } catch (err) {
            setError('Failed to delete the project');
        }
    };

    const getImageUrl = (imagePath) => {
        if (!imagePath) return '';
        if (imagePath.startsWith('http')) {
            return imagePath;
        }
        if (imagePath.startsWith('/uploads')) {
            return `${config.BASE_URL}${imagePath}`;
        }
        return `${config.BASE_URL}/uploads/${imagePath}`;
    };

    if (loading) return (
        <div className="loading-container">
            <p className="loading-text">Loading...</p>
        </div>
    );

    if (error) return (
        <div className="error-container">
            <p className="error-text">{error}</p>
        </div>
    );

    if (!project) return (
        <div className="no-project-container">
            <p className="no-project-text">No project found</p>
        </div>
    );

    return (
        <div className="dashboard">
            <div className="container">
                <div className="main-section">
                    <div className="form-header">
                        <h1 className="form-title">Program Details</h1>
                        <button
                            onClick={() => navigate(-1)}
                            className="back-button"
                        >
                            Go Back
                        </button>
                    </div>

                    <div className="form-container">
                        <div className="form-sections">
                            {/* Banner Information Section */}
                            <div className="form-section">
                                <h2 className="section-heading">Banner Information</h2>
                                <div className="form-grid">
                                    <div className="form-field">
                                        <label className="form-label">Banner Title</label>
                                        <div className="form-display-value">
                                            {project.program_title || 'Not specified'}
                                        </div>
                                    </div>
                                </div>
                                <div className="form-field-full">
                                    <label className="form-label">Banner Description</label>
                                    <div className="form-display-value">
                                        {project.banner_description || 'No banner description'}
                                    </div>
                                </div>
                                <div className="form-field">
                                    <label className="form-label">Is Featured</label>
                                    <div className="form-display-value">
                                        {project.isFetured === 'true' ? 'Yes' : 'No'}
                                    </div>
                                </div>
                                {project.featuredImage && (
                                    <div className="form-field">
                                        <label className="form-label">Featured Image</label>
                                        <div className="image-preview">
                                            <img
                                                src={getImageUrl(project.featuredImage)}
                                                alt="Featured"
                                                className="preview-image"
                                                onError={(e) => {
                                                    console.error('Image failed to load:', project.featuredImage);
                                                    e.target.style.display = 'none';
                                                }}
                                            />
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* After Banner Information Section */}
                            <div className="form-section">
                                <h2 className="section-heading">After Banner Information</h2>
                                <div className="form-grid">
                                    <div className="form-field">
                                        <label className="form-label">Title</label>
                                        <div className="form-display-value">
                                            {project.title || 'Not specified'}
                                        </div>
                                    </div>
                                    {/* <div className="form-field">
                                        <label className="form-label">Category</label>
                                        <div className="form-display-value">
                                            {project.category || 'Not specified'}
                                        </div>
                                    </div> */}
                                </div>
                                <div className="form-field-full">
                                    <label className="form-label">Description</label>
                                    <div className="form-display-value">
                                        {project.description || 'No description'}
                                    </div>
                                </div>
                                <div className="form-field">
                                    <label className="form-label">Slug</label>
                                    <div className="form-display-value">
                                        {project.slug || 'No slug'}
                                    </div>
                                </div>
                            </div>

                            {/* Gallery Images Section */}
                            {project.galleryImages && project.galleryImages.length > 0 && (
                                <div className="form-section">
                                    <h2 className="section-heading">Gallery Images</h2>
                                    <div className="gallery-grid">
                                        {project.galleryImages.map((image, index) => (
                                            <div key={index} className="gallery-item">
                                                <div className="form-field">
                                                    <label className="form-label">Gallery Image {index + 1}</label>
                                                    <div className="image-preview">
                                                        <img
                                                            src={getImageUrl(image)}
                                                            alt={`Gallery image ${index + 1}`}
                                                            className="preview-image"
                                                            onError={(e) => {
                                                                console.error('Gallery image failed to load:', image);
                                                                e.target.style.display = 'none';
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Tabs Section */}
                            {project.tabs && project.tabs.length > 0 && (
                                <div className="form-section">
                                    <div className="tabs-header">
                                        <h2 className="section-heading">Program Tabs</h2>
                                    </div>

                                    <div className="tabs-navigation">
                                        {project.tabs.map((tab, tabIndex) => (
                                            <button
                                                key={tab.id}
                                                onClick={() => setActiveTab(tabIndex)}
                                                className={`tab-button ${activeTab === tabIndex ? 'active' : ''}`}
                                            >
                                                {tab.tabTitle}
                                            </button>
                                        ))}
                                    </div>

                                    {project.tabs[activeTab] && (
                                        <div className="tab-container">
                                            <div className="tab-header">
                                                <h3 className="tab-title">
                                                    {project.tabs[activeTab].tabTitle}
                                                </h3>
                                            </div>

                                            <div className="tab-fields">
                                                <div className="form-grid">
                                                    <div className="form-field">
                                                        <label className="form-label">Tab Title</label>
                                                        <div className="form-display-value">
                                                            {project.tabs[activeTab].tabTitle || 'Not specified'}
                                                        </div>
                                                    </div>
                                                    <div className="form-field">
                                                        <label className="form-label">Title</label>
                                                        <div className="form-display-value">
                                                            {project.tabs[activeTab].title || 'Not specified'}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="form-field-full">
                                                    <label className="form-label">Description</label>
                                                    <div className="form-display-value">
                                                        {project.tabs[activeTab].description || 'No description'}
                                                    </div>
                                                </div>
                                            </div>

                                            {/* Sections */}
                                            {project.tabs[activeTab].sections && project.tabs[activeTab].sections.length > 0 && (
                                                <div className="sections-container">
                                                    <div className="sections-header">
                                                        <h4 className="sections-title">Sections</h4>
                                                    </div>

                                                    {project.tabs[activeTab].sections.map((section, sectionIndex) => (
                                                        <div key={sectionIndex} className="section-container">
                                                            <div className="section-header">
                                                                <h5 className="section-title">Section {sectionIndex + 1}</h5>
                                                            </div>

                                                            <div className="section-fields">
                                                                <div className="form-field">
                                                                    <label className="form-label">Section Title</label>
                                                                    <div className="form-display-value">
                                                                        {section.title || 'Not specified'}
                                                                    </div>
                                                                </div>
                                                                <div className="form-field-full">
                                                                    <label className="form-label">Section Description</label>
                                                                    <div className="form-display-value">
                                                                        {section.description || 'No description'}
                                                                    </div>
                                                                </div>
                                                                {section.image && (
                                                                    <div className="form-field">
                                                                        <label className="form-label">Section Image</label>
                                                                        <div className="image-preview">
                                                                            <img
                                                                                src={getImageUrl(section.image)}
                                                                                alt={section.title}
                                                                                className="preview-image"
                                                                                onError={(e) => {
                                                                                    console.error('Section image failed to load:', section.image);
                                                                                    e.target.style.display = 'none';
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                )}
                                                            </div>

                                                            {/* Subtabs */}
                                                            {section.subtabs && section.subtabs.length > 0 && (
                                                                <div className="subtabs-container">
                                                                    <div className="subtabs-header">
                                                                        <h6 className="subtabs-title">Subtabs</h6>
                                                                    </div>

                                                                    {section.subtabs.map((subtab, subtabIndex) => (
                                                                        <div key={subtab.id} className="subtab-container">
                                                                            <div className="subtab-header">
                                                                                <span className="subtab-title">Subtab {subtabIndex + 1}</span>
                                                                            </div>

                                                                            <div className="subtab-fields">
                                                                                <div className="form-field">
                                                                                    <label className="form-label">Subtab Title</label>
                                                                                    <div className="form-display-value">
                                                                                        {subtab.tabTitle || 'Not specified'}
                                                                                    </div>
                                                                                </div>
                                                                                <div className="form-field">
                                                                                    <label className="form-label">Title</label>
                                                                                    <div className="form-display-value">
                                                                                        {subtab.title || 'Not specified'}
                                                                                    </div>
                                                                                </div>
                                                                                <div className="form-field-full">
                                                                                    <label className="form-label">Description</label>
                                                                                    <div className="form-display-value">
                                                                                        {subtab.description || 'No description'}
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            {/* Subtab Sections */}
                                                                            {subtab.sections && subtab.sections.length > 0 && (
                                                                                <div className="subsections-container">
                                                                                    <div className="subsections-header">
                                                                                        <span className="subsections-title">Sections</span>
                                                                                    </div>

                                                                                    {subtab.sections.map((subSection, subSectionIndex) => (
                                                                                        <div key={subSection.id} className="subsection-container">
                                                                                            <div className="subsection-header">
                                                                                                <span className="subsection-title">Section {subSectionIndex + 1}</span>
                                                                                            </div>
                                                                                            <div className="subsection-fields">
                                                                                                <div className="form-field">
                                                                                                    <label className="form-label">Title</label>
                                                                                                    <div className="form-display-value">
                                                                                                        {subSection.title || 'Not specified'}
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div className="form-field-full">
                                                                                                    <label className="form-label">Description</label>
                                                                                                    <div className="form-display-value">
                                                                                                        {subSection.description || 'No description'}
                                                                                                    </div>
                                                                                                </div>
                                                                                                {subSection.image && (
                                                                                                    <div className="form-field">
                                                                                                        <label className="form-label">Image</label>
                                                                                                        <div className="image-preview">
                                                                                                            <img
                                                                                                                src={getImageUrl(subSection.image)}
                                                                                                                alt={subSection.title}
                                                                                                                className="preview-image"
                                                                                                                onError={(e) => {
                                                                                                                    console.error('Subsection image failed to load:', subSection.image);
                                                                                                                    e.target.style.display = 'none';
                                                                                                                }}
                                                                                                            />
                                                                                                        </div>
                                                                                                    </div>
                                                                                                )}
                                                                                            </div>
                                                                                        </div>
                                                                                    ))}
                                                                                </div>
                                                                            )}
                                                                        </div>
                                                                    ))}
                                                                </div>
                                                            )}
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            )}

                            {/* Action Buttons */}
                            <div className="submit-section">
                                <div className="action-buttons">
                                    <button
                                        onClick={handleDelete}
                                        className="delete-button"
                                    >
                                        Delete
                                    </button>
                                    <Link
                                        to={`/admin/update-program/${project._id}`}
                                        className="submit-button"
                                    >
                                        Edit Program
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ProjectDetails;