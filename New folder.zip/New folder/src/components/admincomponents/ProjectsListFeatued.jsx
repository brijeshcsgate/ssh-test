import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import {
    DndContext,
    closestCenter,
    KeyboardSensor,
    PointerSensor,
    useSensor,
    useSensors,
} from '@dnd-kit/core';
import {
    arrayMove,
    SortableContext,
    sortableKeyboardCoordinates,
    verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import config from '../../config';

// Sortable Item Component
function SortableProjectItem({ project, index }) {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging,
    } = useSortable({ 
        id: project._id,
        data: {
            project: project,
            index: index
        }
    });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.8 : 1,
    };

    return (
        <div
            ref={setNodeRef}
            style={style}
            className={`project-row ${isDragging ? 'project-row-dragging' : ''}`}
        >
            {/* Drag handle */}
            <div
                {...attributes}
                {...listeners}
                className="drag-handle"
            >
                <span className="index-badge">
                    {index + 1}
                </span>
                <span className="grip-hint">⋮⋮</span>
            </div>

            {/* Content */}
            <div className="project-row-content">
                <div className="project-row-text">
                    <h3 className="project-title-text">
                        {project.title.split(" ").length > 15
                            ? project.title.split(" ").slice(0, 15).join(" ") + "..."
                            : project.title}
                    </h3>
                </div>
                <div className="project-row-actions">
                    <Link
                        to={`/admin/programs/${project._id}`}
                        className="view-button"
                    >
                        View Details
                    </Link>
                </div>
            </div>
        </div>
    );
}

function ProjectsListFeatured() {
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const sensors = useSensors(
        useSensor(PointerSensor),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );

    const fetchProjects = async () => {
        try {
            const response = await axios.get(
                `${config.BASE_URL}/api/admin/get-featured-projects`,
                { withCredentials: true }
            );

            if (response.data) {
                setProjects(response.data);
            }
        } catch (err) {
            setError(`Failed to fetch projects: ${err.response?.data?.message || err.message}`);
        } finally {
            setLoading(false);
        }
    };

    const handleDragEnd = async (event) => {
        const { active, over } = event;
        if (!over || active.id === over.id) {
            return;
        }

        const oldIndex = projects.findIndex((project) => project._id === active.id);
        const newIndex = projects.findIndex((project) => project._id === over.id);

        const newProjects = arrayMove(projects, oldIndex, newIndex);
        setProjects(newProjects);

        try {
            const positionData = newProjects.map((project, index) => ({
                id: project._id,
                position: index + 1,
            }));

            await axios.post(
                `${config.BASE_URL}/api/admin/update-project-positions`,
                { positions: positionData },
                { 
                    withCredentials: true,
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            );
            setError('');
        } catch (err) {
            setError(`Failed to update project positions: ${err.response?.data?.message || err.message}`);
            fetchProjects();
        }
    };

    useEffect(() => {
        fetchProjects();
    }, []);

    return (
        <div className="dashboard">
            <div className="container">
                <h1 className="dash_title">Featured Projects</h1>
                <div className="main-section">
                    <div className="projects">
                        <div className="projects-inner">
                            <header className="projects-header">
                                <div className="projects-count">
                                    <span className="count-label">Total</span>
                                    <span className="count-value">{projects.length} Projects</span>
                                </div>
                            </header>

                            {loading ? (
                                <div className="loading-container"><p className="loading-text">Loading projects...</p></div>
                            ) : error ? (
                                <div className="error-message">{error}</div>
                            ) : (
                                <DndContext
                                    sensors={sensors}
                                    collisionDetection={closestCenter}
                                    onDragEnd={handleDragEnd}
                                >
                                    <SortableContext
                                        items={projects.map((p) => p._id)}
                                        strategy={verticalListSortingStrategy}
                                    >
                                        <div className="project-list">
                                            {projects.length === 0 ? (
                                                <div className="no-project-container">
                                                    <p className="no-project-text">No projects found.</p>
                                                </div>
                                            ) : (
                                                projects.map((project, index) => (
                                                    <SortableProjectItem
                                                        key={project._id}
                                                        project={project}
                                                        index={index}
                                                    />
                                                ))
                                            )}
                                        </div>
                                    </SortableContext>
                                </DndContext>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ProjectsListFeatured;
