import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams, useNavigate, Link } from "react-router-dom";
import config from '../../config';

function CategoryDetails() {
    const { id } = useParams();
    const [category, setCategory] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const fetchCategoryDetails = async () => {
        try {
            const response = await axios.get(`${config.BASE_URL}/api/admin/categories/${id}`, { withCredentials: true });
            setCategory(response.data.data);
        } catch (err) {
            console.error('Error fetching category details:', err);
            if (err.response?.status === 404) {
                setError('Category not found');
            } else if (err.response?.status === 401) {
                setError('Unauthorized. Please login again.');
                navigate('/admin/login');
                return;
            } else {
                setError('Failed to fetch category details');
            }
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        fetchCategoryDetails();
    }, [id]);

    const handleDelete = async () => {
        if (!window.confirm('Are you sure you want to delete this category? This action cannot be undone.')) {
            return;
        }

        try {
            await axios.delete(`${config.BASE_URL}/api/admin/categories/${id}`, { withCredentials: true });
            // Navigate back to the categories list
            navigate('/admin/category');
        } catch (err) {
            console.error('Error deleting category:', err);
            if (err.response?.status === 401) {
                setError('Unauthorized. Please login again.');
                navigate('/admin/login');
            } else if (err.response?.status === 404) {
                setError('Category not found');
            } else {
                setError('Failed to delete the category');
            }
        }
    };

    // Format date helper
    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    if (loading) return (
        <div className="loading-container">
            <p className="loading-text">Loading category details...</p>
        </div>
    );

    if (error) return (
        <div className="error-container">
            <div className="error-message">
                <p className="error-text">{error}</p>
                <button
                    onClick={() => navigate(-1)}
                    className="back-button"
                >
                    Go Back
                </button>
            </div>
        </div>
    );

    if (!category) return (
        <div className="no-project-container">
            <p className="no-project-text">No category found</p>
            <button
                onClick={() => navigate(-1)}
                className="back-button"
            >
                Go Back
            </button>
        </div>
    );

    return (
        <div className="dashboard">
            <div className="container">
                <div className="main-section">
                    <div className="form-header">
                        <h1 className="form-title">Category Details</h1>
                        <button
                            onClick={() => navigate(-1)}
                            className="back-button"
                        >
                            Go Back
                        </button>
                    </div>

                    <div className="form-container">
                        <div className="form-sections">
                            <div className="form-section">
                                <h2 className="section-heading">Category Name</h2>
                                <p className="info-value">{category.name}</p>
                            </div>

                            <div className="form-section">
                                <h2 className="section-heading">Description</h2>
                                <div className="tab-section-content">
                                    {category.description ? (
                                        <p className="info-value">{category.description}</p>
                                    ) : (
                                        <p className="info-value">No description provided</p>
                                    )}
                                </div>
                            </div>

                            <div className="form-section">
                                <h2 className="section-heading">Timestamps</h2>
                                <div className="form-grid">
                                    <div className="form-field">
                                        <label className="form-label">Created At</label>
                                        <p className="info-value">{formatDate(category.createdAt)}</p>
                                    </div>
                                    <div className="form-field">
                                        <label className="form-label">Last Updated</label>
                                        <p className="info-value">{formatDate(category.updatedAt)}</p>
                                    </div>
                                </div>
                            </div>

                            <div className="form-section">
                                <h2 className="section-heading">Category ID</h2>
                                <p className="info-value">{category._id}</p>
                            </div>
                        </div>

                        <div className="action-buttons">
                            <button
                                onClick={handleDelete}
                                className="delete-button"
                            >
                                Delete Category
                            </button>
                            <Link
                                to={`/admin/category-update/${category._id}`}
                                className="edit-button"
                            >
                                Edit Category
                            </Link>
                        </div>

                        {error && (
                            <div className="error-message">
                                {error}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CategoryDetails;