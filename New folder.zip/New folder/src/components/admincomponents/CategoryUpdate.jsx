
import React, { useState, useEffect } from 'react';
import { Save } from 'lucide-react';
import { useNavigate, useParams } from 'react-router-dom';
import config from '../../config';
import axios from "axios";

const CategoryUpdate = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const [formData, setFormData] = useState({
    name: '',
    description: ''
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  useEffect(() => {
    const fetchCategory = async () => {
      try {
        const response = await axios.get(`${config.BASE_URL}/api/admin/categories/${id}`, {
          withCredentials: true,
          headers: {
            'Content-Type': 'application/json'
          }
        });

        if (response.data) {
          setFormData({
            name: response.data.data.name || '',
            description: response.data.data.description || ''
          });
        }
      } catch (err) {
        console.error('Error fetching category:', err);

        if (err.response?.status === 404) {
          setErrors({ submit: 'Category not found' });
        } else if (err.response?.status === 401) {
          setErrors({ submit: 'Authentication failed. Please login again.' });
          setTimeout(() => {
            navigate('/admin/login');
          }, 2000);
        } else {
          setErrors({ submit: 'Failed to fetch category details' });
        }
      } finally {
        setLoading(false);
      }
    };

    fetchCategory();
  }, [id, navigate]);

  // Generic input change handler
  const handleInputChange = (field, value) => {
    console.log('Input change - Field:', field, 'Value:', value);

    setFormData(prev => ({
      ...prev,
      [field]: value
    }));

    // Clear any existing error for this field
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  // Form validation
  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Category name is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Submit form
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    setErrors({});

    try {
      const response = await axios.put(
        `${config.BASE_URL}/api/admin/categories/${id}`,
        {
          name: formData.name.trim(),
          description: formData.description.trim()
        },
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json"
          }
        }
      );

      console.log('Update response:', response);

      if (response.status === 200) {
        setSuccessMessage('Category updated successfully!');
        setTimeout(() => {
          navigate("/admin/category");
        }, 2000);
      }
    } catch (err) {
      console.error('Error updating category:', err);

      let errorMessage = "Failed to update category";

      if (err.response?.data?.message) {
        errorMessage = err.response.data.message;
      } else if (err.response?.status === 400) {
        errorMessage = "Invalid category data provided";
      } else if (err.response?.status === 404) {
        errorMessage = "Category not found";
      } else if (err.response?.status === 409) {
        errorMessage = "Category name already exists";
      } else if (err.response?.status === 401) {
        errorMessage = "Authentication failed. Please login again.";
        setTimeout(() => {
          navigate('/admin/login');
        }, 2000);
      }

      setErrors({ submit: errorMessage });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <p className="loading-text">Loading category...</p>
      </div>
    );
  }

  return (
    <div className="dashboard">
      <div className="container">
        <div className="main-section">
          <div className="form-header">
            <h1 className="form-title">Update Category</h1>
            <button
              onClick={() => navigate(-1)}
              className="back-button"
            >
              Go Back
            </button>
          </div>

          <div className="form-container">
            {/* {successMessage && (
              <div className="success-message">
                {successMessage}
              </div>
            )} */}

            <form onSubmit={handleSubmit} className="category-form">
              <div className="form-section">
                <h2 className="section-heading">Category Information</h2>
                <div className="form-fields">
                  {/* Category Name */}
                  <div className="form-field">
                    <label className="form-label">
                      Category Name *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      className={`form-input ${errors.name ? 'form-input-error' : ''}`}
                      placeholder="Enter category name"
                      required
                      disabled={isSubmitting}
                    />
                    {errors.name && (
                      <p className="error-text">{errors.name}</p>
                    )}
                  </div>

                  {/* Category Description */}
                  <div className="form-field">
                    <label className="form-label">
                      Description
                    </label>
                    <textarea
                      value={formData.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                      rows="4"
                      className="form-textarea"
                      placeholder="Enter category description (optional)"
                      disabled={isSubmitting}
                    />
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="submit-section">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="submit-button"
                >
                  <Save className="icon" />
                  {isSubmitting ? 'Updating Category...' : 'Update Category'}
                </button>
              </div>

              {errors.submit && (
                <div className="error-message">
                  {errors.submit}
                </div>
              )}
            </form>
          </div>
        </div >
      </div >
    </div>
  );
};

export default CategoryUpdate;