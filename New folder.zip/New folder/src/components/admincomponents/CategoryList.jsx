import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import config from "../../config";

function CategoryList() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchCategories = async () => {
    try {
      const response = await axios.get(
        `${config.BASE_URL}/api/admin/categories`,
        { withCredentials: true }
      );
      if (response.data.data) {
        setCategories(response.data.data);
      }
    } catch (err) {
      setError("Failed to fetch categories");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  return (
    <div className="dashboard">
      <div className="container">
        <h1 className="dash_title">Categories</h1>
        <div className="main-section">
          <div className="projects">
            <div className="projects-inner">
              <header className="projects-header">
                <div className="title">
                  Total
                  <div className="count"> {categories.length} Categories</div>
                </div>
                
                <div className="add_project">
                  <Link to="/admin/category-add">Add Category</Link>
                </div>
              </header>
              <table className="projects-table">
                <thead>
                  <tr>
                    <th>Category Name</th>
                    <th>Description</th>
                    <th className="text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan="3">Loading...</td>
                    </tr>
                  ) : error ? (
                    <tr>
                      <td colSpan="3">{error}</td>
                    </tr>
                  ) : (
                    categories?.map((category) => (
                      <tr key={category._id}>
                        <td><p>{category.name}</p></td>
                        <td><p>{category.description}</p></td>
                        <td>
                          <Link
                            to={`/admin/category-details/${category._id}`}
                            className="view_detail"
                          >
                            View Details
                          </Link>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CategoryList;
