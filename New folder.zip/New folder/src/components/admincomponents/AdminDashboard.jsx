import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import config from '../../../src/config';

function AdminDashboard({ onLogout }) {
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchProjects = async () => {
            try {
                const response = await axios.get(`${config.BASE_URL}/api/admin/get-projects`, { withCredentials: true });
                setProjects(response.data); 
            } catch (err) {
                setError('Failed to fetch projects');
            } finally {
                setLoading(false);
            }
        };

        fetchProjects();
    }, []);

    return (
        <>
            <div className="dashboard">
                <div className="container">
                    <h1 className="dash_title">Dashboard</h1>
                    <div className="main-section_dashboard">
                        <div className="content">
                            <div className="cards">
                                <div className="card red">
                                    <i className="fas fa-folder-open">
                                    </i>
                                    <div className="number">
                                        {projects.length}
                                    </div>
                                    <div className="label">
                                        Total Projects
                                    </div>
                                </div>
                            </div>
                            <div className="user-info">
                                {projects.map((project, index) => (
                                    <div className="details" key={project._id}>
                                        <div className="name">
                                            {project.title}
                                        </div>
                                        <div className="tweet">
                                            {project.brandDirection}
                                        </div>
                                    </div>
                                ))}
                                <i className="fab fa-twitter">
                                </i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default AdminDashboard;
