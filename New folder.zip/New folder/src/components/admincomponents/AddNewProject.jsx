
import React, { useEffect, useState } from 'react';
import { Upload, Plus, Trash2, Save, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import config from '../../config';
import axios from "axios";
import Select from "react-dropdown-select";

const AddNewProject = () => {
  const navigate = useNavigate();
  const defaultTabs = [
    {
      id: `tab-1-${Date.now()}`,
      tabTitle: 'Tab 1',
      title: '',
      description: '',
      sections: [],
      isDefault: true,
      restrictions: { titleOnly: true, allowImage: false, allowSubtabs: false, allowSectionsDetails: true }
    },
    {
      id: `tab-2-${Date.now()}`,
      tabTitle: 'Tab 2',
      title: '',
      description: '',
      sections: [],
      isDefault: true,
      restrictions: { titleOnly: false, allowImage: true, allowSubtabs: false, allowSectionsDetails: true }
    },
    {
      id: `tab-3-${Date.now()}`,
      tabTitle: 'Tab 3',
      title: '',
      description: '',
      sections: [],
      isDefault: true,
      restrictions: { titleOnly: true, allowImage: false, allowSubtabs: false, allowSectionsDetails: true }
    },
    {
      id: `tab-4-${Date.now()}`,
      tabTitle: 'Tab 4',
      title: '',
      description: '',
      sections: [],
      isDefault: true,
      restrictions: { titleOnly: false, allowImage: false, allowSubtabs: true, allowSectionsDetails: false }
    }
  ];
  const [sessionId] = useState(`project_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const [isCleaningUp, setIsCleaningUp] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    title: '',
    category: [],
    isFetured: '',
    description: '',
    program_title: '',
    banner_description: '',
    featuredImage: '',
    Image: '',
    galleryImages: [],
    tabs: defaultTabs
  });
  const [categories, setCategories] = useState([]);

  const [uploadingFiles, setUploadingFiles] = useState({});
  const [errors, setErrors] = useState({});
  const [options, setOptions] = useState([])
  const [uploadedFiles, setUploadedFiles] = useState(new Set());

  const cleanupOrphanedImages = async () => {
    if (isSubmitting || isCleaningUp) {
      console.log('Skipping cleanup - submitting or already cleaning up');
      return;
    }

    setIsCleaningUp(true);

    try {
      console.log('Starting cleanup for session:', sessionId);
      const response = await fetch(`${config.BASE_URL}/api/admin/cleanup-orphaned-images`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ sessionId })
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Cleanup completed:', result);
      } else {
        console.error('Cleanup failed with status:', response.status);
      }
    } catch (error) {
      console.error('Error during cleanup:', error);
    } finally {
      setIsCleaningUp(false);
    }
  };

  const handleNavigation = async (path) => {
    await cleanupOrphanedImages();
    navigate(path);
  };

  const handleBackButton = async () => {
    await cleanupOrphanedImages();
    navigate(-1);
  };

  useEffect(() => {
    if (isSubmitting) {
      console.log('hh')
    }
    else {
      cleanupOrphanedImages();
    }
  }, []);

  useEffect(() => {
    const handleBeforeUnload = () => {
      if (!isCleaningUp && !isSubmitting) {
        navigator.sendBeacon(
          `${config.BASE_URL}/api/admin/cleanup-orphaned-images`,
          JSON.stringify({ sessionId })
        );
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [sessionId, isCleaningUp, isSubmitting]);

  useEffect(() => {
    axios.get(`${config.BASE_URL}/api/admin/categories/list`)
      .then((res) => {
        if (res.data.success) {
          setCategories(res.data.data);
          setOptions(res?.data?.data?.map(cat => ({
            label: cat.name,
            value: cat._id
          })))
        }
      })
      .catch((err) => console.error("Failed to fetch categories:", err));
  }, []);

  const selectedOptions = options.filter(opt =>
    formData.category?.includes(opt.value)
  );

  const handleFileUpload = async (file, fieldPath, index = null) => {
    if (!file) return;

    const uploadKey = index !== null ? `${fieldPath}-${index}` : fieldPath;
    setUploadingFiles(prev => ({ ...prev, [uploadKey]: true }));

    try {
      const uploadFormData = new FormData();
      uploadFormData.append('file', file);
      uploadFormData.append('sessionId', sessionId);

      const response = await fetch(`${config.BASE_URL}/api/admin/upload`, {
        method: 'POST',
        credentials: 'include',
        body: uploadFormData
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const result = await response.json();
      const imageUrl = result.fileUrl;
      const uploadedFileName = result.filename || file.name;
      setUploadedFiles(prev => new Set([...prev, uploadedFileName]));

      setFormData(prev => {
        const newData = { ...prev };

        if (fieldPath === 'galleryImages') {
          newData.galleryImages = [...newData.galleryImages];
          newData.galleryImages[index] = imageUrl;
        } else if (fieldPath.includes('tabs')) {
          const pathParts = fieldPath.split('.');
          let current = newData;
          for (let i = 0; i < pathParts.length - 1; i++) {
            const part = pathParts[i];
            if (part.includes('[') && part.includes(']')) {
              const [arrayName, indexStr] = part.split('[');
              const arrayIndex = parseInt(indexStr.replace(']', ''));
              current[arrayName] = [...current[arrayName]];
              current[arrayName][arrayIndex] = { ...current[arrayName][arrayIndex] };
              current = current[arrayName][arrayIndex];
            } else {
              current[part] = { ...current[part] };
              current = current[part];
            }
          }

          current[pathParts[pathParts.length - 1]] = imageUrl;
        } else {
          newData[fieldPath] = imageUrl;
        }
        return newData;
      });
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload file. Please try again.');
    } finally {
      setUploadingFiles(prev => {
        const newUploading = { ...prev };
        delete newUploading[uploadKey];
        return newUploading;
      });
    }
  };

  const handleManualCleanup = async () => {
    try {
      await cleanupOrphanedImages();
      alert('Manual cleanup completed!');
    } catch (error) {
      alert('Manual cleanup failed: ' + error.message);
    }
  };

  const handleInputChange = (path, value) => {
    setFormData(prev => {
      const newData = { ...prev };
      const pathParts = path.split('.');
      let current = newData;
      for (let i = 0; i < pathParts.length - 1; i++) {
        const part = pathParts[i];
        if (part.includes('[') && part.includes(']')) {
          const [arrayName, indexStr] = part.split('[');
          const arrayIndex = parseInt(indexStr.replace(']', ''));
          current[arrayName] = [...current[arrayName]];
          current[arrayName][arrayIndex] = { ...current[arrayName][arrayIndex] };
          current = current[arrayName][arrayIndex];
        } else {
          current[part] = { ...current[part] };
          current = current[part];
        }
      }
      current[pathParts[pathParts.length - 1]] = value;
      return newData;
    });
  };

  const addTab = () => {
    const newTab = {
      id: `tab-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      tabTitle: '',
      title: '',
      description: '',
      sections: [],
      isDefault: false,
      restrictions: { titleOnly: false, allowImage: true, allowSubtabs: true }
    };
    setFormData(prev => {
      const newData = { ...prev };
      newData.tabs = [...newData.tabs, newTab];
      console.log('Updated formData after adding tab:', newData);
      return newData;
    });
  };

  const removeTab = (tabIndex) => {
    if (formData.tabs[tabIndex].isDefault) {
      alert('Cannot remove default tabs');
      return;
    }

    setFormData(prev => ({
      ...prev,
      tabs: prev.tabs.filter((_, index) => index !== tabIndex)
    }));
  };

  // const addSection = (tabIndex) => {
  //   const tab = formData.tabs[tabIndex];
  //   const newSection = {
  //     id: `tab-${tabIndex}-section-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
  //     title: '',
  //     description: '',
  //     image: tab.restrictions.allowImage ? '' : undefined,
  //     subtabs: tab.restrictions.allowSubtabs ? [] : undefined
  //   };

  //   setFormData(prev => {
  //     const newData = { ...prev };
  //     newData.tabs[tabIndex] = {
  //       ...newData.tabs[tabIndex],
  //       sections: [...newData.tabs[tabIndex].sections, newSection]
  //     };
  //     return newData;
  //   });
  // };



  const addSection = (tabIndex) => {
    const tab = formData.tabs[tabIndex];
    // Generate unique ID using timestamp + random string + section count
    const uniqueId = `tab-${tabIndex}-section-${Date.now()}-${Math.random().toString(36).substr(2, 9)}-${tab.sections.length}`;

    const newSection = {
      id: uniqueId,
      title: '',
      description: '',
      image: tab.restrictions.allowImage ? '' : undefined,
      subtabs: tab.restrictions.allowSubtabs ? [] : undefined
    };

    setFormData(prev => {
      const newData = { ...prev };
      newData.tabs = [...newData.tabs]; // Create new array
      newData.tabs[tabIndex] = {
        ...newData.tabs[tabIndex],
        sections: [...newData.tabs[tabIndex].sections, newSection]
      };
      return newData;
    });
  };
  const removeSection = (tabIndex, sectionIndex) => {
    setFormData(prev => {
      const newData = { ...prev };
      newData.tabs[tabIndex] = {
        ...newData.tabs[tabIndex],
        sections: newData.tabs[tabIndex].sections.filter((_, index) => index !== sectionIndex)
      };
      console.log('Updated formData after removing section:', newData);
      return newData;
    });
  };

  const addSubtab = (tabIndex, sectionIndex) => {
    const newSubtab = {
      id: `tab-${tabIndex}-section-${sectionIndex}-subtab-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      tabTitle: '',
      title: '',
      description: '',
      sections: []
    };
    setFormData(prev => {
      const newData = { ...prev };
      newData.tabs[tabIndex].sections[sectionIndex] = {
        ...newData.tabs[tabIndex].sections[sectionIndex],
        subtabs: [...newData.tabs[tabIndex].sections[sectionIndex].subtabs, newSubtab]
      };
      return newData;
    });
  };

  const removeSubtab = (tabIndex, sectionIndex, subtabIndex) => {
    console.log('Removing subtab', subtabIndex, 'from section', sectionIndex, 'in tab', tabIndex);
    setFormData(prev => {
      const newData = { ...prev };
      newData.tabs[tabIndex].sections[sectionIndex] = {
        ...newData.tabs[tabIndex].sections[sectionIndex],
        subtabs: newData.tabs[tabIndex].sections[sectionIndex].subtabs.filter((_, index) => index !== subtabIndex)
      };
      return newData;
    });
  };

  const addSubtabSection = (tabIndex, sectionIndex, subtabIndex) => {
    const newSection = {
      id: `tab-${tabIndex}-section-${sectionIndex}-subtab-${subtabIndex}-section-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      title: '',
      description: '',
      image: ''
    };
    setFormData(prev => {
      const newData = { ...prev };
      newData.tabs[tabIndex].sections[sectionIndex].subtabs[subtabIndex] = {
        ...newData.tabs[tabIndex].sections[sectionIndex].subtabs[subtabIndex],
        sections: [...newData.tabs[tabIndex].sections[sectionIndex].subtabs[subtabIndex].sections, newSection]
      };
      return newData;
    });
  };

  const removeSubtabSection = (tabIndex, sectionIndex, subtabIndex, subSectionIndex) => {
    console.log('Removing subtab section', subSectionIndex, 'from subtab', subtabIndex, 'in section', sectionIndex, 'of tab', tabIndex);
    setFormData(prev => {
      const newData = { ...prev };
      newData.tabs[tabIndex].sections[sectionIndex].subtabs[subtabIndex] = {
        ...newData.tabs[tabIndex].sections[sectionIndex].subtabs[subtabIndex],
        sections: newData.tabs[tabIndex].sections[sectionIndex].subtabs[subtabIndex].sections.filter((_, index) => index !== subSectionIndex)
      };
      return newData;
    });
  };

  const addGalleryImage = () => {
    setFormData(prev => ({
      ...prev,
      galleryImages: [...prev.galleryImages, '']
    }));
  };

  const removeGalleryImage = (index) => {
    setFormData(prev => ({
      ...prev,
      galleryImages: prev.galleryImages.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `${config.BASE_URL}/api/admin/add-project`,
        formData,
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/json",
            ...(token ? { 'Authorization': token } : {})
          }
        }
      );

      if ((response.status === 200)||(response.status === 201)) {
        const token = localStorage.getItem("token");
        setIsSubmitting(true)
        navigate("/admin/programs");
      }
    } catch (err) {
      const errorMessage = err.response?.data?.message || "Failed to add programs";
      console.error("Error:", errorMessage);
      setErrors({ submit: errorMessage });
    }
  };

  const FileInput = ({ label, value, onUpload, fieldPath, index = null }) => {
    const uploadKey = index !== null ? `${fieldPath}-${index}` : fieldPath;
    const isUploading = uploadingFiles[uploadKey];

    return (
      <div className="file-input-container">
        <label className="file-input-label">{label}</label>
        <div className="file-input-wrapper">
          <input
            type="file"
            accept="image/*"
            onChange={(e) => onUpload(e.target.files[0], fieldPath, index)}
            className="file-input"
            disabled={isUploading}
          />
          {isUploading && <span className="uploading-text">Uploading...</span>}
        </div>

        {value && (
          <div className="image-preview">
            <img
              src={value}
              alt="Uploaded"
              className="preview-image"
            />
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="dashboard">
      <div className="container">
        <div className="main-section">
          <div className="form-header">
            <h1 className="form-title">Add Program</h1>
            <button
              onClick={() => navigate(-1)}
              className="back-button"
            >
              Go Back
            </button>
          </div>

          <div className="form-container">
            <div className="form-sections">
              <div className="form-section">
                <h2 className="section-heading">Banner Information</h2>
                <div className="form-grid">
                  <div className="form-field">
                    <label className="form-label">Banner Title *</label>
                    <input
                      type="text"
                      value={formData.program_title}
                      onChange={(e) => handleInputChange('program_title', e.target.value)}
                      className="form-input"
                      required
                    />
                  </div>
                </div>
                <div className="form-field-full">
                  <label className="form-label">Banner Description</label>
                  <textarea
                    value={formData.banner_description}
                    onChange={(e) => handleInputChange('banner_description', e.target.value)}
                    rows="2"
                    className="form-textarea"
                  />
                </div>
                <div className="form-field">
                  <label className="form-label">Is Featured</label>
                  <select
                    value={formData.isFetured}
                    onChange={(e) => handleInputChange('isFetured', e.target.value)}
                    className="form-select"
                  >
                    <option value="">Select...</option>
                    <option value="true">Yes</option>
                    <option value="false">No</option>
                  </select>
                </div>
                <div className="form-field">
                  <FileInput
                    label="Featured Image"
                    value={formData.featuredImage}
                    onUpload={handleFileUpload}
                    fieldPath="featuredImage"
                  />
                </div>
              </div>

              <div className="form-section">
                <h2 className="section-heading">After Banner Information</h2>
                <div className="form-grid">
                  <div className="form-field">
                    <label className="form-label">Title *</label>
                    <input
                      type="text"
                      value={formData.title}
                      onChange={(e) => handleInputChange('title', e.target.value)}
                      className="form-input"
                      required
                    />
                  </div>
                  <div className="form-field">
                    <label className="form-label">Category</label>
                    <Select
                      options={options}
                      multi
                      placeholder="Select categories"
                      values={selectedOptions}
                      style={{
                        border: "1px solid #d1d5db",
                        borderRadius: "0.375rem",
                        backgroundColor: "white",
                        color: "black",
                        padding: "4px",
                      }}
                      dropdownStyle={{
                        backgroundColor: "white",
                        color: "black",
                        border: "1px solid #d1d5db",
                        borderRadius: "0.375rem",
                      }}
                      onChange={(selected) => {
                        setFormData(prev => ({
                          ...prev,
                          category: selected.map(s => s.value)
                        }));
                      }}
                    />
                  </div>
                </div>
                <div className="form-field-full">
                  <label className="form-label">Description *</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    rows="3"
                    className="form-textarea"
                    required
                  />
                </div>
              </div>

              <div className="form-section">
                <h2 className="section-heading">Gallery Images</h2>
                <div className="gallery-controls">
                  <button
                    type="button"
                    onClick={addGalleryImage}
                    className="add-button"
                  >
                    <Plus className="icon" /> Add New
                  </button>
                </div>
                {formData.galleryImages.map((image, index) => (
                  <div key={index} className="gallery-item">
                    <div className="gallery-input">
                      <FileInput
                        label={`Gallery Image ${index + 1}`}
                        value={image}
                        onUpload={handleFileUpload}
                        fieldPath="galleryImages"
                        index={index}
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => removeGalleryImage(index)}
                      className="remove-button"
                    >
                      <Trash2 className="icon" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="form-section">
                <div className="tabs-header">
                  <h2 className="section-heading">Tabs</h2>
                  <div className="tabs-controls">
                    <button
                      type="button"
                      onClick={addTab}
                      className="add-button"
                    >
                      <Plus className="icon" /> Add Tab
                    </button>
                  </div>
                </div>

                {formData.tabs.map((tab, tabIndex) => (
                  <div key={tab.id} className="tab-container">
                    <div className="tab-header">
                      <h3 className="tab-title">
                        {tab.isDefault ? `${tab.tabTitle} (Default)` : `Tab ${tabIndex + 1}`}
                        {tab.isDefault && (
                          <span className="tab-restrictions">
                            {tabIndex === 0 && "(Title & Description only)"}
                            {tabIndex === 1 && "(Title, Description & Image)"}
                            {tabIndex === 2 && "(Title & Description only)"}
                            {tabIndex === 3 && "(Subtabs only)"}
                          </span>
                        )}
                      </h3>
                      {!tab.isDefault && (
                        <button
                          type="button"
                          onClick={() => removeTab(tabIndex)}
                          className="remove-tab-button"
                        >
                          <X className="icon" />
                        </button>
                      )}
                    </div>

                    <div className="tab-fields">
                      <div className="form-grid">
                        <div className="form-field">
                          <label className="form-label">Tab Title *</label>
                          <input
                            type="text"
                            value={tab.tabTitle}
                            onChange={(e) => handleInputChange(`tabs[${tabIndex}].tabTitle`, e.target.value)}
                            className="form-input"
                            required
                          />
                        </div>
                        <div className="form-field">
                          <label className="form-label">Title</label>
                          <input
                            type="text"
                            value={tab.title}
                            onChange={(e) => handleInputChange(`tabs[${tabIndex}].title`, e.target.value)}
                            className="form-input"
                          />
                        </div>
                      </div>
                      <div className="form-field-full">
                        <label className="form-label">Description</label>
                        <textarea
                          value={tab.description}
                          onChange={(e) => handleInputChange(`tabs[${tabIndex}].description`, e.target.value)}
                          rows="2"
                          className="form-textarea"
                        />
                      </div>
                    </div>

                    <div className="sections-container">
                      <div className="sections-header">
                        <h4 className="sections-title">Sections</h4>
                        <button
                          type="button"
                          onClick={() => addSection(tabIndex)}
                          className="add-section-button"
                        >
                          <Plus className="icon" /> Add Section
                        </button>
                      </div>

                      {tab.sections.map((section, sectionIndex) => (
                        <div key={section.id} className="section-container">
                          <div className="section-header">
                            <h5 className="section-title">Section {sectionIndex + 1}</h5>
                            <button
                              type="button"
                              onClick={() => removeSection(tabIndex, sectionIndex)}
                              className="remove-section-button"
                            >
                              <X className="icon" />
                            </button>
                          </div>

                          <div className="section-fields">
                            {tab.restrictions.allowSectionsDetails && (
                              <input
                                type="text"
                                placeholder="Section Title *"
                                value={section.title}
                                onChange={(e) => handleInputChange(`tabs[${tabIndex}].sections[${sectionIndex}].title`, e.target.value)}
                                className="form-input-small"
                                required
                              />
                            )}
                            {tab.restrictions.allowSectionsDetails && (
                              <textarea
                                placeholder="Section Description"
                                value={section.description}
                                onChange={(e) => handleInputChange(`tabs[${tabIndex}].sections[${sectionIndex}].description`, e.target.value)}
                                rows="2"
                                className="form-textarea-small"
                              />
                            )}
                            {tab.restrictions.allowImage && (
                              <FileInput
                                label="Section Image"
                                value={section.image}
                                onUpload={handleFileUpload}
                                fieldPath={`tabs[${tabIndex}].sections[${sectionIndex}].image`}
                              />
                            )}
                          </div>

                          {tab.restrictions.allowSubtabs && (
                            <div className="subtabs-container">
                              <div className="subtabs-header">
                                <h6 className="subtabs-title">Subtabs</h6>
                                <button
                                  type="button"
                                  onClick={() => addSubtab(tabIndex, sectionIndex)}
                                  className="add-subtab-button"
                                >
                                  <Plus className="icon" /> Add Subtab
                                </button>
                              </div>

                              {section.subtabs && section.subtabs.map((subtab, subtabIndex) => (
                                <div key={subtab.id} className="subtab-container">
                                  <div className="subtab-header">
                                    <span className="subtab-title">Subtab {subtabIndex + 1}</span>
                                    <button
                                      type="button"
                                      onClick={() => removeSubtab(tabIndex, sectionIndex, subtabIndex)}
                                      className="remove-subtab-button"
                                    >
                                      <X className="icon" />
                                    </button>
                                  </div>

                                  <div className="subtab-fields">
                                    <input
                                      type="text"
                                      placeholder="Title"
                                      value={subtab.title}
                                      onChange={(e) => handleInputChange(`tabs[${tabIndex}].sections[${sectionIndex}].subtabs[${subtabIndex}].title`, e.target.value)}
                                      className="form-input-small"
                                    />
                                    <textarea
                                      placeholder="Description"
                                      value={subtab.description}
                                      onChange={(e) => handleInputChange(`tabs[${tabIndex}].sections[${sectionIndex}].subtabs[${subtabIndex}].description`, e.target.value)}
                                      rows="2"
                                      className="form-textarea-small"
                                    />
                                  </div>

                                  <div className="subsections-container">
                                    <div className="subsections-header">
                                      <span className="subsections-title">Sections</span>
                                      <button
                                        type="button"
                                        onClick={() => addSubtabSection(tabIndex, sectionIndex, subtabIndex)}
                                        className="add-subsection-button"
                                      >
                                        <Plus className="icon" /> Add
                                      </button>
                                    </div>

                                    {subtab.sections.map((subSection, subSectionIndex) => (
                                      <div key={subSection.id} className="subsection-container">
                                        <div className="subsection-header">
                                          <span className="subsection-title">Section {subSectionIndex + 1}</span>
                                          <button
                                            type="button"
                                            onClick={() => removeSubtabSection(tabIndex, sectionIndex, subtabIndex, subSectionIndex)}
                                            className="remove-subsection-button"
                                          >
                                            <X className="icon" />
                                          </button>
                                        </div>
                                        <div className="subsection-fields">
                                          <input
                                            type="text"
                                            placeholder="Title *"
                                            value={subSection.title}
                                            onChange={(e) => handleInputChange(`tabs[${tabIndex}].sections[${sectionIndex}].subtabs[${subtabIndex}].sections[${subSectionIndex}].title`, e.target.value)}
                                            className="form-input-small"
                                            required
                                          />
                                          <textarea
                                            placeholder="Description"
                                            value={subSection.description}
                                            onChange={(e) => handleInputChange(`tabs[${tabIndex}].sections[${sectionIndex}].subtabs[${subtabIndex}].sections[${subSectionIndex}].description`, e.target.value)}
                                            rows="2"
                                            className="form-textarea-small"
                                          />
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="submit-section">
                <button
                  onClick={handleSubmit}
                  className="submit-button"
                >
                  <Save className="icon" /> Submit Form
                </button>
              </div>

              {errors.submit && (
                <div className="error-message">
                  {errors.submit}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddNewProject;