import { Link } from 'react-router-dom';
import { useState } from 'react';
import logo from '../assets/Images/logo.png'; // adjust path if needed

const Header = () => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <header className="position-relative w-100 header_outer top-0 d-py-30 py-15">
            <div className="container">
                <div className="d-flex gap-30 justify-center align-center">
                    {/* Left nav */}
                    <nav className="menu_left d-flex gap-30 justify-center align-center">
                        <Link to="/about" className="text-white uppercase tracking-widest text-sm px-15">About</Link>
                        <Link to="/#" className="text-white uppercase tracking-widest text-sm px-15">Programs</Link>
                    </nav>

                    {/* Logo */}
                    <Link to="/">
                        <img src={logo} alt="Arete Logo" className="h-10" />
                    </Link>

                    {/* Right nav */}
                    <nav className="menu_right d-flex gap-30 justify-center align-center">
                        <Link to="#" className="text-white uppercase tracking-widest text-sm px-15">Reviews</Link>
                        <Link to="#" className="text-white uppercase tracking-widest text-sm px-15"><strong>Start Now</strong> </Link>
                    </nav>

                    <div className="mail_icon position-absolute end-0 pe-60  ">
                        <Link to="mailto:example@gmail.com">
                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                                <path d="M14.7158 4.58984C14.8301 4.49902 15 4.58398 15 4.72754V10.7188C15 11.4951 14.3701 12.125 13.5938 12.125H1.40625C0.629883 12.125 0 11.4951 0 10.7188V4.73047C0 4.58398 0.166992 4.50195 0.28418 4.59277C0.94043 5.10254 1.81055 5.75 4.79883 7.9209C5.41699 8.37207 6.45996 9.32129 7.5 9.31543C8.5459 9.32422 9.60938 8.35449 10.2041 7.9209C13.1924 5.75 14.0596 5.09961 14.7158 4.58984ZM7.5 8.375C8.17969 8.38672 9.1582 7.51953 9.65039 7.16211C13.5381 4.34082 13.834 4.09473 14.7305 3.3916C14.9004 3.25977 15 3.05469 15 2.83789V2.28125C15 1.50488 14.3701 0.875 13.5938 0.875H1.40625C0.629883 0.875 0 1.50488 0 2.28125V2.83789C0 3.05469 0.0996094 3.25684 0.269531 3.3916C1.16602 4.0918 1.46191 4.34082 5.34961 7.16211C5.8418 7.51953 6.82031 8.38672 7.5 8.375Z" fill="white" />
                            </svg>
                        </Link>
                    </div>
                    {/* Hamburger Icon */}
                    <button className="hamburger_btn" onClick={() => setIsOpen(!isOpen)}>
                        <span className="bar"></span>
                        <span className="bar"></span>
                        <span className="bar"></span>
                    </button>
                </div>
            </div>

            {/* Mobile Drawer Menu */}
            <div className={`mobile_drawer d-flex ${isOpen ? 'open' : ''}`}>
                <div className="overlay"></div>
                <div className='drawer_inner'>
                    <button className="close_btn position-absolute end-0 top-0" onClick={() => setIsOpen(false)}>✖</button>
                    <nav className="mobile_nav d-flex gap-30 pt-30 flex-column align-start">
                        <Link to="/about" onClick={() => setIsOpen(false)}>About</Link>
                        <Link to="/programs" onClick={() => setIsOpen(false)}>Programs</Link>
                        <Link to="/reviews" onClick={() => setIsOpen(false)}>Reviews</Link>
                        <Link to="/service" onClick={() => setIsOpen(false)}><strong>Start Now</strong></Link>
                        <Link to="mailto:example@gmail.com">
                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="13" viewBox="0 0 15 13" fill="none">
                                <path d="M14.7158 4.58984C14.8301 4.49902 15 4.58398 15 4.72754V10.7188C15 11.4951 14.3701 12.125 13.5938 12.125H1.40625C0.629883 12.125 0 11.4951 0 10.7188V4.73047C0 4.58398 0.166992 4.50195 0.28418 4.59277C0.94043 5.10254 1.81055 5.75 4.79883 7.9209C5.41699 8.37207 6.45996 9.32129 7.5 9.31543C8.5459 9.32422 9.60938 8.35449 10.2041 7.9209C13.1924 5.75 14.0596 5.09961 14.7158 4.58984ZM7.5 8.375C8.17969 8.38672 9.1582 7.51953 9.65039 7.16211C13.5381 4.34082 13.834 4.09473 14.7305 3.3916C14.9004 3.25977 15 3.05469 15 2.83789V2.28125C15 1.50488 14.3701 0.875 13.5938 0.875H1.40625C0.629883 0.875 0 1.50488 0 2.28125V2.83789C0 3.05469 0.0996094 3.25684 0.269531 3.3916C1.16602 4.0918 1.46191 4.34082 5.34961 7.16211C5.8418 7.51953 6.82031 8.38672 7.5 8.375Z" fill="white" />
                            </svg>
                        </Link>
                    </nav>
                </div>
            </div>

        </header>
    );
};

export default Header;