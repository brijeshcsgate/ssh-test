import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import ArrowWhiteRight from '../assets/icons/white-arrow-right.svg';
import '../assets/style.css'
import Image1 from '../assets/Images/tab_item1.jpg';
import Image2 from '../assets/Images/tab_item2.jpg';
import Image3 from '../assets/Images/tab_item3.jpg';
import Image4 from '../assets/Images/tab_item4.jpg';
import addIcon from '../assets/icons/add.svg';
import axios from 'axios';
import config from '../config';


// const categories = ['Weight Loss', 'Athletic Performance', 'Hormone Balance'];

const services = {
    'Weight Loss': [
        { title: 'Functional Movement', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.', image: Image1 },
        { title: 'Functional Medicine', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.', image: Image2 },
        { title: 'Health Coaching', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.', image: Image3 },
        { title: 'Coaching for HER', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.', image: Image4 },
    ],
    'Athletic Performance': [
        { title: 'Coaching for HIM', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.', image: Image2 },
        { title: 'Personal Training', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.', image: Image1 },
    ],
    'Hormone Balance': [
        { title: 'Functional Immunology', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.', image: Image1 },
        { title: 'Functional Endocrinology', description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.', image: Image2 },
    ],
};


const TabSection = ({ onSelectProgram, programs }) => {
    const [activeCategory, setActiveCategory] = useState(0);
    const navigate = useNavigate()
    const [activeCategoryId, setActiveCategoryId] = useState(0);
    const [categories, setCategories] = useState([]);

    useEffect(() => {
        axios.get(`${config.BASE_URL}/api/admin/categories/list`)
            .then((res) => {
                if (res.data.success && res.data.data.length > 0) {
                    setCategories(res.data.data);
                    setActiveCategory(0);
                    setActiveCategoryId(res.data.data[0]._id);
                }
            })
            .catch((err) => console.error("Failed to fetch categories:", err));
    }, []);

    const handleCategory = (id, cat_id) => {
        setActiveCategory(id);
        setActiveCategoryId(cat_id)
    }

    const handleServices = (id) => {
        navigate(`/service/${id}`)
    }

    return (
        <div className="tabs overflow-hidden pt-60 pb-120 text-black categories_tab">
            <div className="container">
                <div className="d-flex gap-20 grid-items flex-wrap">
                    {/* Left Tabs */}
                    <div className="left-block grid-item">
                        <h6 className="sub_heading mb-15">PERSONALIZED</h6>
                        <h2 className="mb-15 letter-spacing-0">create your own program</h2>
                        <p>Select services you are interested in to curate a program for you. Our team will guide you on creating and starting a personalized program.</p>
                        <p className='mt-20'>Explore by category:</p>
                        {/* Category Buttons */}
                        <div className="d-flex flex-column align-start gap-15 pt-20">
                            {categories.map((category, index) => (
                                <button
                                    key={index}
                                    onClick={() => handleCategory(index, category._id)}
                                    className={`rounded-full button d-flex gap-10 align-center ${activeCategory === index ? 'active' : ''}`}
                                >
                                    {category.name}
                                    {activeCategory === index && (<img src={ArrowWhiteRight} alt="" className="ml-2 inline-block" />)}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Right Services */}
                    <div className="right-block grid-item">
                        <div className="top-block pb-70 d-flex justify-end flex-wrap position-relative">
                            <Link to="/" className="learn_more button button-primary d-flex fs-10 mb-40 gap-10 align-center">
                                BUILD YOUR OWN <img src={ArrowWhiteRight} alt="Home Icon" />
                            </Link>
                            <hr />
                        </div>


                        <div className="grid-items">
{/* programs?.filter(item => activeCategoryIds.includes(item?.category)) */}

                            {/* {programs?.filter(item => item?.category === activeCategoryId).map((service, index) => ( */}
                               {programs?.filter(item => item?.category.includes(activeCategoryId)).map((service, index) => (
                           
                                <div key={index} className="grid-item d-flex gap-20 d-align-start">
                                    <div className='image-block'>
                                        <img src={service?.featuredImage} alt={service?.program_title} className="w-16 h-16 rounded-full object-cover" />
                                    </div>

                                    <div className='summary-block d-flex flex-column align-start gap-15'>
                                        <h5 className="font-semibold cursor-pointer" onClick={() => handleServices(service?._id)}>{service?.program_title}</h5>
                                        <p className="max-w-200">{service?.banner_description}</p>
                                        <button
                                            className="button d-flex gap-10 align-center"
                                            onClick={() => onSelectProgram(service)} // trigger overlay
                                        >
                                            ADD <span className="text-lg leading-none d-flex"><img src={addIcon} alt="" /></span>
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TabSection;
