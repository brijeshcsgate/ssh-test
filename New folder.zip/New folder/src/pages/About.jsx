import { Link } from 'react-router-dom';
import { useEffect } from 'react';
import bannerImage from '../assets/Images/about_banner.jpg';
import aboutImage from '../assets/Images/about-image.jpg';
import WhoWeAre from '../assets/Images/who_we_are.jpg'
import claritybannerImage from '../assets/Images/clarity-banner.jpg';
import ArrowWhiteRight from '../assets/icons/white-arrow-right.svg';
import serviceRichtext1 from '../assets/Images/service_richtext1.jpg';
import serviceRichtext2 from '../assets/Images/service_richtext2.jpg';
import OurStory from '../assets/Images/Our_story.jpg'
import YellowCross from '../assets/icons/yellow_cross.svg'
import Header from '../components/Header';


const About = () => {

    useEffect(() => {
        const sectionss = document.querySelectorAll("[id]");
        const navLinkss = document.querySelectorAll(".about_page .tab-link");

        const onScroll = () => {
            const scrollY = window.pageYOffset;

            sectionss.forEach((section) => {
                const sectionTop = section.offsetTop - 100;
                const sectionHeight = section.offsetHeight;

                if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                    navLinkss.forEach((link) => {
                        link.classList.remove("active");
                        if (link.getAttribute("href") === `#${section.id}`) {
                            link.classList.add("active");
                        }
                    });
                }
            });
        };

        window.addEventListener("scroll", onScroll);
        return () => window.removeEventListener("scroll", onScroll);
    }, []);

    return (
        <>
        <Header />
        
        <div className=" about_page">
            {/* Hero Section */}
            <div className="image-banner text-white overlay bg-position-center-bottom full-screen content_center home_hero position-relative" style={{ backgroundImage: `url(${bannerImage})` }}  >
                <div className="container">
                    <div className="summary-block text-center position-relative">
                        <h1 className='pb-25 line-height-110 d-fs-28 fs-24'>Your Premier Destination for <br />
                            Precision Health and Wellness
                        </h1>
                    </div>
                </div>
            </div>

            <div className="sticky-bar about_sticky_bar d-py-40 py-10 position-sticky top-0">
                <div className="container position-relative">
                    <ul className="nav-tabs d-flex justify-center d-gap-40 gap-15 row-gap-5">
                        <li><a href="#approach" className="tab-link d-fs-14 fs-12 fw-300 d-pe-40 pe-20 position-relative">OUR APPROACH</a></li>
                        <li><a href="#who_we_are" className="tab-link d-fs-14 fs-12 fw-300 d-pe-40 pe-20 position-relative">WHO WE ARE</a></li>
                        <li><a href="#our_story" className="tab-link d-fs-14 fs-12 fw-300 d-pe-40 pe-20 position-relative">OUR STORY</a></li>
                        <li><a href="#json" className="tab-link d-fs-14 fs-12 fw-300 position-relative">DR. JASON</a></li>
                    </ul>
                </div>
            </div>

            {/* Rich Text with Images */}
            <div className="rich_text text-white d-pt-110 pt-60 pb-60 bg-dark" id='approach'>
                <div className="container">
                    <div className="summary-block d-flex gap-25 align-center text-center flex-column max-w-700 ms-auto me-auto d-mb-60 mb-40">
                        <h2 className='text-center d-mb-20 letter-spacing-0 line-height-110'>Arete Health is a private health and wellness boutique offering bespoke care plans in West Palm Beach.</h2>
                        <p className='fs-14 fw-400 line-height-100 font-primary uppercase'>Your Healthcare Can Be So Much More </p>
                        <p className='text-center fs-16'>Here's a shortened version that keeps the core message and tone:
                            At Arete Health, we break down silos by integrating chiropractic care, physiotherapy, personal training, health coaching, and functional medicine—under one roof. Our approach is rooted in data, using biometric tracking, lab diagnostics, imaging, and movement assessments to create personalized, evolving care plans.
                            <br /><br />
                            We go beyond symptom relief to target root causes and deliver real, lasting outcomes. Whether you're recovering, managing chronic issues, or aiming for peak performance, our team works together to restore function, optimize health, and empower transformation.
                            At Arete, we believe in excellence over routine, clarity over complexity, and relationships over transactions. We're not just treating patients—we’re redefining healthcare.
                        </p>
                    </div>
                    <div className="images-block d-flex gap-10">
                        <div className="large_image d-flex">
                            <img src={serviceRichtext1} alt="" />
                        </div>
                        <div className="small_image d-flex">
                            <img src={serviceRichtext2} alt="" />
                        </div>
                    </div>
                    <div className="summary-block d-flex gap-25 align-center text-center flex-column max-w-750 ms-auto me-auto d-mt-60 mt-40">
                        <p className='text-center fs-16 '>
                            At Arete Health, we don't chase symptoms-we pursue root causes, meaningful outcomes, and lifelong transformation. What sets us apart is our integrated model that blends functional medicine, personalized health coaching, advanced diagnostics, chiropractic care, and evidence-based movement systems-all under one roof. We don't believe in fragmented care or short-term fixes. Instead, we invest in deep relationships, long-term vision, and proactive strategies that empower our patients to evolve, not just recover. We are different because we value excellence over routine, clarity over complexity, continuity over quick fixes, human connection over transaction, and self-leadership over dependency. We're not just building healthier people—we're building a new standard of healthcare.
                        </p>
                    </div>
                </div>
            </div>

            {/* Rich text banner */}
            <div className="rich-text-banner text-white position-relative d-pt-120 pt-60 d-pb-160 pb-70" id='who_we_are' style={{ backgroundImage: `url(${WhoWeAre})` }} >
                <div className="container position-relative">
                    <div className="top-block d-pb-200 pb-60">
                        <div className="summary-block max-w-600 d-grid gap-25">
                            <h2>Who we are</h2>
                            <p className='fs-16 fw-400'>
                                At Arete Health, we unite functional medicine, movement science, chiropractic, neurology, and health coaching to help you feel, move, and live at your best. Healing starts with relationships, so we listen closely and consider your full life context.
                                <br /><br />
                                Our care is personalized, intentional, and focused on lasting vitality—not just symptom relief. We partner with patients who are ready to engage and take charge of their health. With the right team, tools, and mindset, we help you discover what’s truly possible.
                            </p>
                        </div>
                    </div>
                    <div className="bottom-block d-pt-100 d-pb-150">
                        <div className="grid-items d-grid d-column-2 d-gap-50 gap-40">
                            <div className="grid-item d-flex align-center">
                                <div className="buttons-group d-flex flex-column align-start gap-15">
                                    <Link href='' className="button-secondary button rounded-full ms-30 uppercase letter-spacing-02 font-primary fw-400"> <img src={YellowCross} alt="" /> generic protocols</Link>
                                    <Link href='' className="button-secondary button rounded-full uppercase letter-spacing-02 font-primary fw-400"> <img src={YellowCross} alt="" /> reactive care</Link>
                                    <Link href='' className="button-secondary button rounded-full ms-30 uppercase letter-spacing-02 font-primary fw-400"> <img src={YellowCross} alt="" /> SINGLE APPROACH</Link>
                                </div>
                            </div>
                            <div className="grid-item">
                                <div className="summary-block d-text-right max-w-500 me-0 d-ms-auto d-grid gap-25">
                                    <h2>Who we are not</h2>
                                    <p className='fs-16 letter-spacing-001 line-height-180'>At Arete Health, we are not a quick-fix, symptom-chasing, insurance-driven clinic-and we're proud of that. We don't offer generic protocols, rushed appointments, or a one-size-fits-all approach to health. If you're looking for a pill-for-every-ill model or reactive care that starts and ends with lab results, we may not be the right fit. But if you value proactive, personalized, and integrative care that honors the complexity of the human body and the importance of long-term relationships, you're in the right place.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            {/* Rich Text with Images */}
            <div className="rich_text text-white d-pt-110 pt-60 pb-60 bg-dark-olive" id='our_story'>
                <div className="container">
                    <div className="summary-block d-flex gap-25 align-center text-center flex-column max-w-700 ms-auto me-auto d-mb-60 mb-40">
                        <h2 className='text-center d-mb-20 letter-spacing-0 line-height-110'>Our Story</h2>
                        <p className='fs-12 fw-400 line-height-100 font-primary'>NO BOARDROOM, NO BUSINESS PLAN</p>
                        <p className='text-center fs-16'>
                            Arete Health didn’t begin in a boardroom or with a business plan - it began in a 500 square foot studio with a quiet, unresolved frustration in a system that felt fractured at its foundation: a system that too often treated people as charts and checklists, chased disease rather than preventing it, and left both practitioners and patients unsatisfied in their experience. As a clinician navigating his own health journey, Dr. Jason McCloskey saw a disheartening paradox. Within the conventional medical world, brilliant minds were shackled by bureaucracy and subjugated by insurance policies that delayed and fragmented intervention. In the world alternative healthcare, where personalization promised more, he encountered the exact opposite. This time the system wasn’t to blame, the providers were. Unspecific protocols, wellness trend-chasing influencers marketed as science-based experts, and a lack of continuity or accountability throughout a patient’s lifespan. On both sides, expertise was diluted, connection was rare, and care felt more like a transaction than a relationship.
                        </p>
                    </div>
                    <div className="images-block d-flex gap-10 max-w-700 ms-auto me-auto">
                        <div className="small_image d-flex">
                            <img src={OurStory} alt="" />
                        </div>
                    </div>
                    <div className="summary-block d-flex gap-25 align-center text-center flex-column max-w-700 ms-auto me-auto d-mt-60 mt-40">
                        <p className='text-center fs-16'>
                            He knew there had to be another way, and after two years of research and development, Arete Health was born. Built on a foundation of scientific precision, whole-person care, and uncompromising integrity, Arete Health offers something radical and powerful in its simplicity: care that is thoughtful, individualized, and deeply human. It conjoins the clinical rigor of evidence-based medicine with the empathy, agency, and wholisitic philosphy often found in the best of alternative approaches. The result is a model that doesn’t just treat what’s wrong—it helps uncover what’s possible. At its heart, Arete Health is more than a clinic. It’s a proof of concept - a new standard for what healthcare can be when it’s built not around systems, but around people.
                        </p>
                    </div>
                </div>
            </div>

            {/* text with image Section */}
            <div className="text-with-image text-black home-text-with-image" id='json'>
                <div className="grid-items d-grid d-column-2">
                    <div className="grid-item d-pt-90 d-pb-70 py-50 pe-20">
                        <div className="summary-block d-flex justify-between flex-column h-full ">
                            <div className="top-block">
                                <h6 className='sub-heading mb-20 '>MEET DR. JASON</h6>
                                <h3 className='max-w-350 mb-30 font-secondary  line-height-120'>Arete Health is the creation of Dr. Jason McCloskey</h3>
                                <p className='fs-16 max-w-450 mb-30'>Dr. McCloskey is a healthcare polyspecialist and human performance coach who takes a lifestyle-first approach to complex cases and high-performing individuals. After a decade of mentorship under top integrative health experts, he saw firsthand how lifestyle factors could transform even the toughest medical outcomes. He founded Arete Health to reflect his broad clinical expertise and commitment to personalized, integrative care. Now a nationally recognized clinician, speaker, and consultant, Dr. McCloskey is redefining lifestyle medicine with uncommon depth and precision.</p>
                            </div>
                            <div className="bottom-block">
                                <Link to="/" className="button button-primary w-fit d-flex gap-10 align-center">CONTACT <img src={ArrowWhiteRight} alt="Home Icon" /></Link>
                            </div>
                        </div>
                    </div>
                    <div className="grid-item">
                        <div className="image-block h-full d-flex">
                            <img className='object-cover' src={aboutImage} alt="" />
                        </div>
                    </div>
                </div>
            </div>


            {/* Image Banner Section */}
            <div className="image-banner text-white content_center d-overlay bg-position-bottom-center position-relative" style={{ backgroundImage: `url(${claritybannerImage})` }} >
                <div className="container">
                    <div className="summary-block text-center position-relative d-flex flex-wrap flex-column align-center">
                        <h6 className='sub-heading mb-20 fw-500'>GET CLARITY</h6>
                        <h2 className='mb-30'>get a recommended program</h2>
                        <Link to="/" className="button button-secondary d-flex align-center gap-10">FILL OUT OUR QUESTIONNAIRE <img src={ArrowWhiteRight} alt="Home Icon" /></Link>
                    </div>
                </div>
            </div>

        </div>
        </>
    );
};

export default About;