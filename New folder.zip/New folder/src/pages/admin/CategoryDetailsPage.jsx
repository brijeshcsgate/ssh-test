import React from "react";
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import DashboardHeader from '../../components/admincomponents/DashboardHeader';
import CategoryDetails from "../../components/admincomponents/CategoryDetails";

function ViewCategory({onLogout}) {
  return (
    <>
      <DashboardHeader onLogout={onLogout}/>
      <CategoryDetails />            
    </>
  );
}

export default ViewCategory;
