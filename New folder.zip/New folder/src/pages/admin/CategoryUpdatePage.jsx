import React from "react";
import DashboardHeader from '../../components/admincomponents/DashboardHeader';
import CategoryUpdate from "../../components/admincomponents/CategoryUpdate";

function UpdateCategory({onLogout}) {
  return (
    <>
      <DashboardHeader onLogout={onLogout}/>
      <CategoryUpdate />            
    </>
  );
}

export default UpdateCategory;
