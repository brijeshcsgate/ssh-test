import React from "react";
import DashboardHeader from '../../components/admincomponents/DashboardHeader';
import CategoryList from "../../components/admincomponents/CategoryList";

function Categorys({onLogout}) {
  return (
    <>
      <DashboardHeader onLogout={onLogout}/>
      <CategoryList  />            
    </>
  );
}

export default Categorys;
