import React from "react";
import DashboardHeader from '../../components/admincomponents/DashboardHeader';
import ProjectsListFeatured from "../../components/admincomponents/ProjectsListFeatued";

function FeaturedProjects({onLogout}) {
  return (
    <>
      <DashboardHeader onLogout={onLogout}/>
      <ProjectsListFeatured  />            
    </>
  );
}

export default FeaturedProjects;
