import React from "react";
import DashboardHeader from '../../components/admincomponents/DashboardHeader';
import CategoryAdd from "../../components/admincomponents/CategoryAdd";

function AddCategory({onLogout}) {
  return (
    <>
      <DashboardHeader onLogout={onLogout}/>
      <CategoryAdd />            
    </>
  );
}

export default AddCategory;
