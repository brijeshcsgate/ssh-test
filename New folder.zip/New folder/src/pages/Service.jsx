import { Link, useNavigate, useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import bannerImage from '../assets/Images/service_banner.jpg';
import serviceRichtext1 from '../assets/Images/service_richtext1.jpg';
import serviceRichtext2 from '../assets/Images/service_richtext2.jpg';
import Program1 from '../assets/Images/programme1.jpg';
import Program2 from '../assets/Images/programme2.jpg';
import Program3 from '../assets/Images/programme3.jpg';
import SportsTabSection from '../components/sports-tabs.jsx';
import AthleticDevelopment from '../components/AthleticDevelopment.jsx'
import axios from 'axios';
import config from '../config.js';
import Header from '../components/Header.jsx';


const Service = () => {

    const { id } = useParams();
    const [program, setProgram] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [activeTab, setActiveTab] = useState(0);
    const navigate = useNavigate();

    const fetchProgramDetails = async () => {
        try {
            const response = await axios.get(`${config.BASE_URL}/api/admin/get-project/${id}`, { withCredentials: true });
            setProgram(response.data);
        } catch (err) {
            setError('Failed to fetch project details');
        } finally {
            setLoading(false);
        }
    }

    useEffect(() => {
        fetchProgramDetails();
    }, [id]);

    useEffect(() => {
        const sections = document.querySelectorAll("[id]");
        const navLinks = document.querySelectorAll(".tab-link");

        const onScroll = () => {
            const scrollY = window.pageYOffset;

            sections.forEach((section) => {
                const sectionTop = section.offsetTop - 100;
                const sectionHeight = section.offsetHeight;

                if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
                    navLinks.forEach((link) => {
                        link.classList.remove("active");
                        if (link.getAttribute("href") === `#${section.id}`) {
                            link.classList.add("active");
                        }
                    });
                }
            });
        };

        window.addEventListener("scroll", onScroll);
        return () => window.removeEventListener("scroll", onScroll);
    }, []);


    const programs = [
        {
            title: 'package one',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',
            image: Program1,
        },
        {
            title: 'package two',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',
            image: Program2,
        },
        {
            title: 'package three',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',
            image: Program3,
        },
        {
            title: 'package three',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',
            image: Program3,
        },
    ];
    const summaryData = [
        {
            title: "Build a Strong Athletic Foundation",
            text: "Develop coordination, balance, and movement skills that support any sport or activity."
        },
        {
            title: "Build a Strong Athletic Foundation",
            text: "Develop coordination, balance, and movement skills that support any sport or activity."
        },
        {
            title: "Prevent Injuries",
            text: "Improve biomechanics, stability, and recovery to reduce injury risk over time."
        },
        {
            title: "Prevent Injuries",
            text: "Improve biomechanics, stability, and recovery to reduce injury risk over time."
        },
        {
            title: "Enhance Performance",
            text: "Increase speed, strength, power, and agility in a structured, age-appropriate progression."
        },
        {
            title: "Enhance Performance",
            text: "Increase speed, strength, power, and agility in a structured, age-appropriate progression."
        }
    ];
    return (
        <>
        <Header/>
        
        <div className="">
            {/* Hero Section */}
            <div className="image-banner text-white full-screen content_center home_hero d-overlay position-relative" style={{ backgroundImage: `url(${program?.featuredImage})` }}  >
                <div className="container">
                    <div className="summary-block text-center position-relative">
                        {/* <h1 className='pb-25'>Athletic Development</h1>
                        <p className='fs-16 mb-30'>A Program for Game Changers</p> */}
                        <h1 className='pb-25'>{program?.program_title}</h1>
                        <p className='fs-16 mb-30'>{program?.banner_description}</p>

                        <a href="#" className="button button-secondary ">START NOW</a>
                    </div>
                </div>
            </div>

            {/* Rich Text with Images */}
            <div className="rich_text text-white d-pt-110 pt-60 pb-60 bg-dark">
                <div className="container">
                    <div className="summary-block d-flex gap-35 align-center text-center flex-column max-w-700 ms-auto me-auto d-mb-60 mb-40">
                        {/* <h2 className='text-center letter-spacing-001 line-height-110'>Arete Health’s Long Term Athletic Development program is built for those who don’t just want to play the game—they want to change it</h2>
                        <p className='text-center fs-16'>Designed for athletes of all ages and stages, this progressive, science-backed system goes beyond traditional training to shape resilient, high-performing individuals from the ground up. Whether you're raising a future all-star, preparing for collegiate competition, or building a foundation for lifelong fitness, our program evolves with you—layering strength, movement, mindset, recovery, and sport-specific mastery into every phase. If you’re ready to elevate your performance and invest in your full athletic potential, welcome to the path built for game changers.</p> */}

                        <h2 className='text-center letter-spacing-001 line-height-110'>{program?.title}</h2>
                        <p className='text-center fs-16'>{program?.description}</p>


                    </div>
                    <div className="images-block d-flex gap-10">
                        <div className="large_image d-flex">
                            {/* <img src={serviceRichtext1} alt="" /> */}

                            <img src={program?.galleryImages[0]} alt="" />
                        </div>
                        <div className="small_image d-flex">
                            {/* <img src={serviceRichtext2} alt="" /> */}

                            <img src={program?.galleryImages[1]} alt="" />
                        </div>
                    </div>
                </div>
            </div>


            <div className="sticky-bar service d-py-40 py-10 position-sticky top-0">
                <div className="container position-relative">
                    <ul className="nav-tabs d-flex justify-center d-gap-40 gap-15 row-gap-5">
                        {/* <li><a href="#why" className="tab-link d-fs-14 fs-12 fw-300 d-pe-40 pe-20 position-relative">Why Athletic Development</a></li>
                        <li><a href="#conditions" className="tab-link d-fs-14 fs-12 fw-300 d-pe-40 pe-20 position-relative">Conditions</a></li>
                        <li><a href="#values" className="tab-link d-fs-14 fs-12 fw-300 d-pe-40 pe-20 position-relative">Key Values</a></li>
                        <li><a href="#services" className="tab-link d-fs-14 fs-12 fw-300 position-relative">Services</a></li> */}
                        <li><a href="#why" className="tab-link d-fs-14 fs-12 fw-300 d-pe-40 pe-20 position-relative">{program?.tabs[0]?.tabTitle}</a></li>
                        <li><a href="#conditions" className="tab-link d-fs-14 fs-12 fw-300 d-pe-40 pe-20 position-relative">{program?.tabs[1]?.tabTitle}</a></li>
                        <li><a href="#values" className="tab-link d-fs-14 fs-12 fw-300 d-pe-40 pe-20 position-relative">{program?.tabs[2]?.tabTitle}</a></li>
                        <li><a href="#services" className="tab-link d-fs-14 fs-12 fw-300 position-relative">{program?.tabs[3]?.tabTitle}</a></li>

                    </ul>
                </div>
            </div>

            {/* Multicolumn Section */}
            <div className="multicolumn d-py-90 py-60" id='why'>
                <div className="container">
                    <div className='header-block text-center'>
                        {/* <p className='sub_heading mb-15'> WHY </p> */}

                        <p className='sub_heading mb-15'> {program?.tabs[0]?.title} </p>
                        {/* <h2 className=''>
                            Athletic Training
                        </h2> */}
                        <h2 className=''>
                            {program?.tabs[0]?.description}
                        </h2>
                    </div>
                    {/* <div className="grid-items d-grid d-column-3 gap-30 d-pt-80 pt-40">
                        <div className="grid-item d-grid d-gap-50 gap-30">
                            <div className="summary-block d-grid gap-15">
                                <div className='title-block'>
                                    <h5 className='fs-18'>Build a Strong Athletic Foundation</h5>
                                </div>
                                <div className="text-block">
                                    <p>Develop coordination, balance, and movement skills that support any sport or activity.</p>
                                </div>
                            </div>
                            <div className="summary-block d-grid gap-15">
                                <div className='title-block'>
                                    <h5 className='fs-18'>Build a Strong Athletic Foundation</h5>
                                </div>
                                <div className="text-block">
                                    <p>Develop coordination, balance, and movement skills that support any sport or activity.</p>
                                </div>
                            </div>
                        </div>
                        <div className="grid-item d-grid d-gap-50 gap-30">
                            <div className="summary-block d-grid gap-15">
                                <div className='title-block'>
                                    <h5 className='fs-18'>Prevent Injuries</h5>
                                </div>
                                <div className="text-block">
                                    <p>Improve biomechanics, stability, and recovery to reduce injury risk over time.</p>
                                </div>
                            </div>
                            <div className="summary-block d-grid gap-15">
                                <div className='title-block'>
                                    <h5 className='fs-18'>Prevent Injuries</h5>
                                </div>
                                <div className="text-block">
                                    <p>Improve biomechanics, stability, and recovery to reduce injury risk over time.</p>
                                </div>
                            </div>
                        </div>
                        <div className="grid-item d-grid d-gap-50 gap-30">
                            <div className="summary-block d-grid gap-15">
                                <div className='title-block'>
                                    <h5 className='fs-18'>Enhance Performance</h5>
                                </div>
                                <div className="text-block">
                                    <p>Increase speed, strength, power, and agility in a structured, age-appropriate progression.</p>
                                </div>
                            </div>
                            <div className="summary-block d-grid gap-15">
                                <div className='title-block'>
                                    <h5 className='fs-18'>Enhance Performance</h5>
                                </div>
                                <div className="text-block">
                                    <p>Increase speed, strength, power, and agility in a structured, age-appropriate progression.</p>
                                </div>
                            </div>
                        </div>

                    </div> */}



                    <div className="grid-items d-grid d-column-3 gap-30 d-pt-80 pt-40">
                        {program?.tabs[0]?.sections?.map((item, idx) => (
                            <div key={idx} className="summary-block d-grid gap-15">
                                <div className="title-block">
                                    <h5 className="fs-18">{item?.title}</h5>
                                </div>
                                <div className="text-block">
                                    <p>{item?.description}</p>
                                </div>
                            </div>
                        ))}
                    </div>

                </div>
            </div>

            {/* Sports Tabs Section */}
            <SportsTabSection services={program?.tabs[1]} indx={program?.tabs[1]?.sections[0]?._id} />

            {/* text with Image box list */}
            <div className="text-with-image-box-list text-white bg-dark-olive d-py-170 py-60" id='values'>
                <div className="container">
                    <div className="grid-items d-grid d-column-2">
                        <div className="grid-item">
                            {/* <h6 className="mb-20 fw-300 fs-14 fw-400">KEY VALUE POINTS</h6>
                            <h2 className="mb-40 d-fs-36 fs-26">of athletic development</h2> */}

                            <h6 className="mb-20 fw-300 fs-14 fw-400">{program?.tabs[2]?.title}</h6>
                            <h2 className="mb-40 d-fs-36 fs-26">{program?.tabs[2]?.description}</h2>
                        </div>
                        {/* <div className="grid-item d-grid d-gap-70 gap-40">
                            <div className="image-text-block d-flex gap-30">
                                <div className="image-block">
                                    <img src="" alt="" />
                                </div>
                                <div className="content-block ps-5">
                                    <h2 className='mb-20 d-fs-28 fs-20'>Value point 1</h2>
                                    <p className='fs-14 letter-spacing-001 max-w-350'>Develop coordination, balance, and movement skills that support any sport or activity.</p>
                                </div>
                            </div>
                            <div className="image-text-block d-flex gap-30">
                                <div className="image-block">
                                    <img src="" alt="" />
                                </div>
                                <div className="content-block ps-5">
                                    <h2 className='mb-20 d-fs-28 fs-20'>Value point 1</h2>
                                    <p className='fs-14 letter-spacing-001 max-w-350'>Develop coordination, balance, and movement skills that support any sport or activity.</p>
                                </div>
                            </div>
                            <div className="image-text-block d-flex gap-30">
                                <div className="image-block">
                                    <img src="" alt="" />
                                </div>
                                <div className="content-block ps-5">
                                    <h2 className='mb-20 d-fs-28 fs-20'>Value point 1</h2>
                                    <p className='fs-14 letter-spacing-001 max-w-350'>Develop coordination, balance, and movement skills that support any sport or activity.</p>
                                </div>
                            </div>
                        </div> */}

                        <div className="grid-item d-grid d-gap-70 gap-40">
                            {program?.tabs[2]?.sections?.map((point, idx) => (
                                <div key={idx} className="image-text-block d-flex gap-30">
                                    <div className="image-block">
                                        <img src='' alt='' />
                                    </div>
                                    <div className="content-block ps-5">
                                        <h2 className="mb-20 d-fs-28 fs-20">{point?.title}</h2>
                                        <p className="fs-14 letter-spacing-001 max-w-350">{point?.description}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* AthleticDevelopment section */}
            <AthleticDevelopment services={program?.tabs[3]} galleryImages={program?.galleryImages}/>


        </div>
        </>
    );
};

export default Service;