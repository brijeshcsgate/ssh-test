import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import bannerImage from '../assets/Images/banner_image.png';
import aboutImage from '../assets/Images/about-image.jpg';
import claritybannerImage from '../assets/Images/clarity-banner.jpg';
import Harmony from '../assets/icons/harmony.svg';
import Bespoke from '../assets/icons/bespoke.svg';
import Immersive from '../assets/icons/immersive.svg';
import Learnmore from '../assets/icons/learn_more_arrow.svg';
import ArrowWhiteRight from '../assets/icons/white-arrow-right.svg';
import Arrowup from '../assets/icons/arrow-up.svg';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper/modules';
import 'swiper/css';
// import 'swiper/css/navigation';
// import 'swiper/css/pagination';
import Program1 from '../assets/Images/programme1.jpg';
import Program2 from '../assets/Images/programme2.jpg';
import Program3 from '../assets/Images/programme3.jpg';
import ProgramTabs from '../components/Categories-tabs';
import Tetimonial1 from '../assets/Images/testimonial1.jpg';
import Tetimonial2 from '../assets/Images/testimonial2.jpg';
import Tetimonial3 from '../assets/Images/testimonial3.jpg';
import ProgramOverlay from '../components/ProgramOverlay';
import ProgramSelectionOverlay from '../components/ProgramSelectionOverlay';
import axios from 'axios';
import config from '../config';
import Header from '../components/Header';

const Home = () => {

    const programs = [
        {
            title: 'package one',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',
            image: Program1,
        },
        {
            title: 'package two',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',
            image: Program2,
        },
        {
            title: 'package three',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',
            image: Program3,
        },
        {
            title: 'package four',
            description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',
            image: Program3,
        },
    ];
    const [projects, setProjects] = useState([]);

    const [featuredPrograms, setFeaturedPrograms] = useState([]);
    const [menus, setmenus] = useState({});
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const fetchProjects = async () => {
        try {
            const response = await axios.get(`${config.BASE_URL}/api/admin/get-projects`, { withCredentials: true });
            console.log('response.data', response.data)
            if (response.data) {
                setProjects(response.data);
            }

        } catch (err) {
            setError('Failed to fetch projects');
        } finally {
            setLoading(false);
        }
    };

    const fetchFeaturedProjects = async () => {
        try {
            const response = await axios.get(`${config.BASE_URL}/api/admin/get-featured-projects/`, { withCredentials: true });
            console.log('response.data---fet', response.data)
            if (response.data) {
                setFeaturedPrograms(response.data);
            }

        } catch (err) {
            setError('Failed to fetch projects');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchProjects();
        fetchFeaturedProjects();
    }, []);

    const [selectedProgram, setSelectedProgram] = useState(null);
    const [showOverlay, setShowOverlay] = useState(false);
    const [showStep2, setShowStep2] = useState(false);

    const openOverlay = (program) => {
        setSelectedProgram(program);
        setShowOverlay(true);
    };

    const closeOverlay = () => {
        setSelectedProgram(null);
        setShowOverlay(false);
        setShowStep2(false);
    };

    const handleSelectThis = () => {
        setShowOverlay(false);
        setShowStep2(true);
    };


    return (
        <><Header />

            <div className="">
                {/* Hero Section */}
                <div className="image-banner text-white full-screen content_center home_hero d-overlay position-relative" style={{ backgroundImage: `url(${bannerImage})` }}  >
                    <div className="container">
                        <div className="summary-block text-center position-relative">
                            <h1 className='mb-40'>A holistic yet tailored approach to wellness.</h1>
                            <a href="#" className="button button-secondary">CREATE YOUR PROGRAM</a>
                        </div>
                    </div>
                </div>


                {/* Multicolumn Section */}
                <div className="multicolumn py-90">
                    <div className="container">
                        <div className='header-block'>
                            <p className='sub_heading mb-15'> WE GO </p>
                            <h2 className='max-w-650'>
                                beyond the norm by using biometric tracking, diagnostics, and functional assessments to create
                                <strong> personalized, data driven plans that adapt to each patient’s evolving needs.</strong>
                            </h2>
                        </div>
                        <div className="grid-items d-grid d-column-3 gap-60 pt-60">
                            <div className="grid-item">
                                <div className="summary-block d-grid gap-30">
                                    <div className="icon-block">
                                        <img src={Harmony} alt="Home Icon" />
                                    </div>
                                    <div className='title-block'>
                                        <h4>Harmony of Classic + Contemporary</h4>
                                    </div>
                                    <div className="text-block">
                                        <p>Modern medicine often overlooks a key truth: exceptional healthcare starts with understanding the deep connection between a patient, their environment, and lifestyle. While lifestyle medicine offers clear benefits, most doctors lack the time and resources to guide patients in areas like nutrition, exercise, sleep, and stress.</p>
                                    </div>
                                    <div className="button-block">
                                        <hr />
                                        <Link to="/" className="learn_more d-flex gap-10 align-center">Learn More <img src={Learnmore} alt="Home Icon" /></Link>
                                    </div>
                                </div>
                            </div>
                            <div className="grid-item d-mt-30">
                                <div className="summary-block d-grid gap-30">
                                    <div className="icon-block">
                                        <img src={Bespoke} alt="Home Icon" />
                                    </div>
                                    <div className="title-block">
                                        <h4>Bespoke Movement + Medicine</h4>
                                    </div>
                                    <div className="text-block">
                                        <p>True personalized care requires deep insight, data, and thoughtful design. We combine biometrics with research-based plans to deliver care that’s uniquely tailored to each patient—something mass-market healthcare simply can't match. Using our adaptive model, we continually adjust each plan to meet evolving needs, addressing the root causes of health issues—not just the symptoms.</p>
                                    </div>
                                    <div className="button-block">
                                        <hr />
                                        <Link to="/" className="learn_more d-flex gap-10 align-center">Learn More <img src={Learnmore} alt="Home Icon" /></Link>
                                    </div>
                                </div>
                            </div>
                            <div className="grid-item">
                                <div className="summary-block d-grid gap-30">
                                    <div className="icon-block">
                                        <img src={Immersive} alt="Home Icon" />
                                    </div>
                                    <div className="title-block">
                                        <h4>Immersive, Exceptional Experiences</h4>
                                    </div>
                                    <div className="text-block">
                                        <p>Our advanced clinical capabilities make us a top destination for whole-patient care—going far beyond symptom management. We help patients unlock the full potential of optimal health: the freedom to live life on their terms.</p>
                                    </div>
                                    <div className="button-block">
                                        <hr />
                                        <Link to="/" className="learn_more d-flex gap-10 align-center">Learn More <img src={Learnmore} alt="Home Icon" /></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Carousel section */}
                <div className="carousel programe-careousel py-90">
                    <div className="container">
                        <div className="header-block d-flex justify-between align-center d-pb-60 pb-40 flex-wrap gap-20">
                            <div className='left-block text-black'>
                                <h6 className="sub_heading mb-10">POPULAR</h6>
                                <h3>explore programs</h3>
                            </div>
                            <div className="right-block">
                                <Link to="/" className="learn_more button button-primary d-flex gap-10 align-center">VIEW ALL PROGRAMS<img src={ArrowWhiteRight} alt="Home Icon" /></Link>
                            </div>
                        </div>
                    </div>

                    <Swiper
                        modules={[Navigation, Pagination]}
                        spaceBetween={5}
                        slidesPerView={1.2}
                        navigation
                        pagination={{ clickable: true }}
                        breakpoints={{
                            768: { slidesPerView: 2 },
                            1024: { slidesPerView: 2.7 },
                        }}
                    >
                        {/* {programs.map((program, index) => (
                        <SwiperSlide key={index}>
                            <div className="slide position-relative"
                                style={{ backgroundImage: `url(${program.image})`, }}
                            >
                                <div className="overlay position-absolute w-100 bottom-0 d-px-35 px-20 d-pb-50 pb-30 text-white" >
                                    <h5 className='mb-15 helvetica_font fw-300 fs-18 letter-spacing-001'>{program.title}</h5>
                                    <p className='max-w-300 helvetica_font fw-300 letter-spacing-0'>{program.description}</p>
                                    <button onClick={() => openOverlay(program)} className="learn_more button w-fit mt-20 d-flex gap-10 align-center" >
                                        VIEW <img src={Arrowup} alt="Home Icon" />
                                    </button>

                                </div>
                            </div>
                        </SwiperSlide>
                    ))} */}

                        {featuredPrograms.map((program, index) => (
                            <SwiperSlide key={index}>
                                <div className="slide position-relative"
                                    style={{ backgroundImage: `url(${program.featuredImage})`, }}
                                >
                                    <div className="overlay position-absolute w-100 bottom-0 d-px-35 px-20 d-pb-50 pb-30 text-white" >
                                        <h5 className='mb-15 helvetica_font fw-300 fs-18 letter-spacing-001'>{program?.program_title}</h5>
                                        <p className='max-w-300 helvetica_font fw-300 letter-spacing-0'>{program?.banner_description}</p>
                                        <button onClick={() => openOverlay(program)} className="learn_more button w-fit mt-20 d-flex gap-10 align-center" >
                                            VIEW <img src={Arrowup} alt="Home Icon" />
                                        </button>

                                    </div>
                                </div>
                            </SwiperSlide>
                        ))}

                    </Swiper>
                </div>


                {/* Program Tabs Section */}
                {/* <ProgramTabs /> */}

                <ProgramTabs onSelectProgram={openOverlay} programs={projects} />

                {/* Image Banner Section */}
                <div className="image-banner text-white content_center d-overlay bg-position-bottom-center position-relative" style={{ backgroundImage: `url(${claritybannerImage})` }}  >
                    <div className="container">
                        <div className="summary-block text-center position-relative d-flex flex-wrap flex-column align-center">
                            <h6 className='sub-heading mb-20 fw-500'>GET CLARITY</h6>
                            <h2 className='mb-30'>get a recommended program</h2>
                            <Link to="/" className="button button-secondary d-flex align-center gap-10">FILL OUT OUR QUESTIONNAIRE <img src={ArrowWhiteRight} alt="Home Icon" /></Link>
                        </div>
                    </div>
                </div>


                {/* Free style Testimonial section */}
                <div className="freestyle-text-image-mullticolumns text-black d-pt-120 d-pb-200 pt-60 pb-60">
                    <div className="container">
                        <div className="header-block text-center pb-50">
                            <h6 className='fw-400 fs-14'>FROM OUR CLIENTS</h6>
                        </div>
                        <div className="grid-items d-flex flex-wrap d-gap-100 gap-40">
                            <div className="grid-item small-column d-grid gap-20">
                                <div className="image-block d-flex">
                                    <img src={Tetimonial1} alt="" />
                                </div>
                                <div className="summary-block">
                                    <p className='pb-25 d-fs-22 fs-16 px-10'>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor”</p>
                                    <h6 className='client_name fw-600 letter-spacing-02 px-10'>CLIENT NAME</h6>
                                </div>
                            </div>
                            <div className="grid-item large-column d-pt-110 d-grid gap-30">
                                <div className="image-block d-flex">
                                    <img src={Tetimonial2} alt="" />
                                </div>
                                <div className="summary-block">
                                    <p className='pb-25 px-15 d-fs-22 fs-16'>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor”</p>
                                    <h6 className='client_name fw-600 letter-spacing-02 px-15'>CLIENT NAME</h6>
                                </div>
                            </div>
                            <div className="grid-item full-width d-flex flex-wrap align-center d-col-gap-45 gap-20">
                                <div className="image-block d-flex d-pb-0">
                                    <img src={Tetimonial3} alt="" />
                                </div>
                                <div className="summary-block ">
                                    <p className='pb-25 d-fs-22 fs-16'>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor”</p>
                                    <h6 className='client_name fw-600 letter-spacing-02'>CLIENT NAME</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                {/* text with image Section */}
                <div className="text-with-image text-black home-text-with-image ">
                    <div className="grid-items d-grid d-column-2">
                        <div className="grid-item d-pt-90 d-pb-70 py-50 pe-20">
                            <div className="summary-block d-flex justify-between flex-column h-full ">
                                <div className="top-block">
                                    <h6 className='sub-heading mb-20 '>ABOUT ARETE HEALTH</h6>
                                    <h3 className='max-w-400 mb-30 font-secondary line-height-120'>Practice in such a way that patient miracles become clinical expectations.</h3>
                                    <p className='fs-14 max-w-350 mb-30'>We provide personalized, integrative care that blends functional medicine, movement science, neurology, and coaching to support long-term vitality through deep relationships and intentional, tailored plans. We’re not a quick-fix clinic—we partner with patients who are ready to take an active role in their health journey, focusing on root causes and lasting resilience rather than symptom-chasing or one-size-fits-all solutions.</p>
                                </div>
                                <div className="bottom-block">
                                    <Link to="/" className="button button-primary w-fit d-flex gap-10 align-center">LEARN MORE <img src={ArrowWhiteRight} alt="Home Icon" /></Link>
                                </div>
                            </div>
                        </div>
                        <div className="grid-item">
                            <div className="image-block h-full d-flex position-relative ">
                                <img className='object-cover' src={aboutImage} alt="" />
                                <div className="position-absolute start-0 bottom-0 d-px-70 d-py-50 px-20 py-20 text-white">
                                    <h2 className='fs-22 fw-300 font-primary '>Meet Dr. Jason McCloskey</h2>
                                    <Link to="/" className="learn_more button w-fit mt-20 d-flex gap-10 align-center" >VIEW<img src={Arrowup} alt="Home Icon" /></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                {showOverlay && (
                    <ProgramOverlay
                        program={selectedProgram}
                        onClose={closeOverlay}
                        onSelect={handleSelectThis}
                    />
                )}

                {showStep2 && (
                    <ProgramSelectionOverlay
                        program={selectedProgram}

                        programs={projects}
                        // programs={programs}
                        onClose={closeOverlay}
                    />
                )}


            </div>
        </>
    );
};

export default Home;