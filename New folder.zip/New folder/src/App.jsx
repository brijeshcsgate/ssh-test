import { Routes, Route, Navigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import Header from './components/Header';
import Home from './pages/Home';
import Service from './pages/Service';
import About from './pages/About';
import './assets/modal.css';
import './assets/custom.css';
import ProtectedRoute from './components/admincomponents/ProtectedRoutes';
import Dashboard from './pages/admin/Dashboard';
import Settings from './pages/admin/Settings';
import AdminLogin from './components/admincomponents/AdminLogin';
import AddProjects from './pages/admin/AddProject';
import UpdateProjects from './pages/admin/UpdateProject';
import AdminProjects from './pages/admin/AdminProjects';
import ViewProjects from './pages/admin/ViewProject';
import ViewMenu from './pages/admin/ViewMenu';
import { PrimeReactProvider } from 'primereact/api';
import "primereact/resources/themes/lara-light-cyan/theme.css";
import Categorys from './pages/admin/CategoryListPage';
import ViewCategory from './pages/admin/CategoryDetailsPage';
import UpdateCategory from './pages/admin/CategoryUpdatePage';
import AddCategory from './pages/admin/CategoryAddPage';
import FeaturedProjects from './pages/admin/AdminProjectsFeatured';
function App() {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const isAdminRoute = window.location.pathname.startsWith('/admin');

    useEffect(() => {
        const body = document.querySelector("body");
        if (isAdminRoute) {
            body.classList.add("adminPanel");
        } else {
            body.classList.remove("adminPanel");
        }

        const token = localStorage.getItem('token');
        if (token) {
            setIsAuthenticated(true);
        }
        setIsLoading(false);
    }, []);

    const handleLogin = () => {
        setIsAuthenticated(true);
    };

    const handleLogout = () => {
        setIsAuthenticated(false);
        localStorage.removeItem('token');
    };

    if (isLoading) {
        return <div>Loading...</div>;
    }

    return (
        
        <PrimeReactProvider>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/service/:id" element={<Service />} />
                <Route path="/about" element={<About />} />
                <Route
                    path="/admin/login"
                    element={
                        isAuthenticated ? (
                            <Navigate to="/admin/dashboard" />
                        ) : (
                            <AdminLogin onLogin={handleLogin} />
                        )
                    }
                />
                <Route
                    path="/admin/dashboard"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <Dashboard onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/programs"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <AdminProjects onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/feat-programs"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <FeaturedProjects onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/add-programs"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <AddProjects onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/programs/:id"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <ViewProjects onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/update-program/:id"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <UpdateProjects onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/category"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <Categorys onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/category-details/:id"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <ViewCategory onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/category-update/:id"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <UpdateCategory onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/category-add"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <AddCategory onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/menus"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <ViewMenu onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/admin/settings"
                    element={
                        <ProtectedRoute isAuthenticated={isAuthenticated}>
                            <Settings onLogout={handleLogout} />
                        </ProtectedRoute>
                    }
                />
            </Routes>
        </PrimeReactProvider>
    );
}

export default App;
