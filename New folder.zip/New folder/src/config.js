// src/config.js
const config = {
     BASE_URL: "http://localhost:5000", 
    FRONTEND_BASE_URL: "http://localhost:3000",
    //  BASE_URL: "http://72.167.149.152:5000", 
    // FRONTEND_BASE_URL: "http://localhost:3000",  
    DATACENTER: "us4"
};
  
export default config;
  