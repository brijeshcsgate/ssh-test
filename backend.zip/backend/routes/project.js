require("dotenv").config();
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const projectController = require('../controllers/project.controller');
const checkAuth = require('../middleware/auth');

const router = express.Router();


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = path.join(__dirname, '..', 'public', 'uploads');
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const upload = multer({ storage });
// Track temporary uploads (in memory - for production, consider using Redis)
const temporaryUploads = new Map();

// Cleanup old temporary uploads (older than 24 hours)
const cleanupOldUploads = () => {
  const now = new Date();
  const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  
  for (const [sessionId, uploads] of temporaryUploads.entries()) {
    const oldUploads = uploads.filter(upload => upload.uploadedAt < oneDayAgo);
    
    if (oldUploads.length > 0) {
      // Remove old files from filesystem
      oldUploads.forEach(upload => {
        try {
          if (fs.existsSync(upload.filepath)) {
            fs.unlinkSync(upload.filepath);
            console.log(`Auto-cleanup: Removed old file ${upload.filename}`);
          }
        } catch (error) {
          console.error(`Error during auto-cleanup of ${upload.filename}:`, error);
        }
      });
      
      // Update the session with remaining uploads
      const remainingUploads = uploads.filter(upload => upload.uploadedAt >= oneDayAgo);
      if (remainingUploads.length === 0) {
        temporaryUploads.delete(sessionId);
      } else {
        temporaryUploads.set(sessionId, remainingUploads);
      }
    }
  }
};

// Run cleanup every hour
setInterval(cleanupOldUploads, 60 * 60 * 1000);
// Run cleanup every hour
setInterval(cleanupOldUploads, 60 * 60 * 1000);

router.post("/upload",  upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded" });
  }

  // Build file URL (assuming server is running at http://localhost:5000)
  const fileUrl = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;

  // Generate a unique session ID for this upload
  const sessionId = req.body.sessionId || `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  // Store the uploaded file info temporarily
  if (!temporaryUploads.has(sessionId)) {
    temporaryUploads.set(sessionId, []);
  }
  temporaryUploads.get(sessionId).push({
    filename: req.file.filename,
    filepath: req.file.path,
    uploadedAt: new Date()
  });

  // Store URL in a variable (example)
  let uploadedFileUrl = fileUrl;
  console.log("Uploaded File URL:", uploadedFileUrl);
  console.log("Session ID:", sessionId);
  console.log("Temporary uploads for session:", temporaryUploads.get(sessionId));

  res.json({ 
    fileUrl: uploadedFileUrl, 
    sessionId: sessionId,
    filename: req.file.filename 
  });
});

// New route to clean up orphaned images
router.post("/cleanup-orphaned-images", async (req, res) => {
  try {
    const { sessionId } = req.body;
    
    if (!sessionId) {
      return res.status(400).json({ error: "Session ID is required" });
    }

    // Get all temporary uploads for this session
    const sessionUploads = temporaryUploads.get(sessionId) || [];
    
    if (sessionUploads.length === 0) {
      return res.json({ message: "No temporary uploads found for this session" });
    }

    // Clean up files from filesystem
    const cleanedFiles = [];
    const errors = [];

    for (const upload of sessionUploads) {
      try {
        if (fs.existsSync(upload.filepath)) {
          fs.unlinkSync(upload.filepath);
          cleanedFiles.push(upload.filename);
          console.log(`Cleaned up file: ${upload.filename}`);
        }
      } catch (error) {
        console.error(`Error cleaning up file ${upload.filename}:`, error);
        errors.push({ filename: upload.filename, error: error.message });
      }
    }

    // Remove session from temporary uploads
    temporaryUploads.delete(sessionId);

    res.json({ 
      message: "Cleanup completed", 
      cleanedFiles, 
      errors,
      totalCleaned: cleanedFiles.length
    });

  } catch (error) {
    console.error('Error during cleanup:', error);
    res.status(500).json({ error: "Cleanup failed", details: error.message });
  }
});

// Route to get temporary uploads for a session
router.get("/temporary-uploads/:sessionId", (req, res) => {
  const { sessionId } = req.params;
  const sessionUploads = temporaryUploads.get(sessionId) || [];
  
  res.json({ 
    sessionId, 
    uploads: sessionUploads,
    count: sessionUploads.length 
  });
});

// router.post("/upload", upload.single("file"), (req, res) => {
//   if (!req.file) {
//     return res.status(400).json({ error: "No file uploaded" });
//   }
//   const fileUrl = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
//   let uploadedFileUrl = fileUrl;
//   console.log("Uploaded File URL:", uploadedFileUrl);

//   res.json({ fileUrl: uploadedFileUrl });
// });
router.delete('/delete-image', (req, res) => {
  const { url } = req.query;

  if (!url) {
    return res.status(400).json({ error: 'URL is required' });
  }

  // Extract filename from the URL
  const filename = path.basename(url);

  // const filePath = path.join(__dirname, 'uploads', filename);
  const filePath = path.join(__dirname, '../uploads', filename)
  fs.unlink(filePath, (err) => {
    if (err) {
      if (err.code === 'ENOENT') {
        return res.status(404).json({ error: 'File not found' });
      }
      return res.status(500).json({ error: 'Error deleting file' });
    }

    res.json({ message: 'File deleted successfully' });
  });
});
router.use("/uploads", express.static(path.join(__dirname, "uploads")));
router.post('/add-project', projectController.addProject);
router.get('/get-projects', projectController.projectsList);
router.get('/get-featured-projects', projectController.projectsFeaturedList);

router.get('/get-project/:id', projectController.getProject);
router.get('/single-project/:slug', projectController.getProjectBySlug);
router.delete('/delete-project/:id', projectController.deleteProject);
router.post('/remove-image', projectController.removeImage);

router.post('/update-featured-projects', projectController.updateProjectFeatured);
router.put('/update-project/:id', projectController.updateProject);
router.post('/update-project-positions', projectController.updateProjectPositions);




module.exports = router;
