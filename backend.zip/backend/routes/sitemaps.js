require('dotenv').config();
const fs = require("fs");
const Project = require('../models/Project');
const { SitemapStream, streamToPromise } = require("sitemap");
const cron = require("node-cron");


const projectsList = async () => {
    try {
        const projects = await Project.find();
        return projects;
    } catch (error) {
        return false;
    }
};


const startSitemapCron = () => {
  
  cron.schedule("*/5 * * * *", () => {
    console.log("⏳ Running sitemap update...");
   
  });

  console.log("🕒 Cron job scheduled: Sitemap updates every 5 minutes.");
};

module.exports = startSitemapCron;
