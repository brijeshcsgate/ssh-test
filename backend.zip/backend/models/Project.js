
const mongoose = require('mongoose');

const ProgramsSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  slug: {
    type: String,
    required: true
  },
  // category: {
  //   type: String,
  // },
  category: [{
    type: String,
   
  }],
  isFetured: {
    type: String,
  },
  description: {
    type: String,
    required: true,
  },
  priority: {
    type: String,
    default:''
  },

  program_title: {
    type: String,
    required: true,
  },
  banner_description: {
    type: String,
    default: '',
  },
  featuredImage: {
    type: String, 
   
  },
  Image: {
    type: String, 
   
  },
  galleryImages: {
    type: [String], 
    default: [],
  },
  tabs: [{
    id: {
      type: String,
      required: true,
    },
    tabTitle: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      default: '',
    },
    description: {
      type: String,
      default: '',
    },
    sections: [{
      id: {
        type: String,
        required: true,
      },
      title: {
        type: String,
        
      },
      description: {
        type: String,
        default: '',
      },
      image: {
        type: String, 
        default: '',
      },
      subtabs: [{
        id: {
          type: String,
          
        },
        tabTitle: {
          type: String,
          
        },
        title: {
          type: String,
          default: '',
        },
        description: {
          type: String,
          default: '',
        },
        sections: [{
          id: {
            type: String,
           
          },
          title: {
            type: String,
            
          },
          description: {
            type: String,
            default: '',
          },
          image: {
            type: String, 
            default: '',
          },
        }]
      }],
    }]
  }]
}, {
  timestamps: {
    createdAt: 'created_at',
    updatedAt: 'updated_at',
  }
});

module.exports = mongoose.model('programs', ProgramsSchema);
