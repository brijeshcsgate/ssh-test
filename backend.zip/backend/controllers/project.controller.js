const Project = require('../models/Project');
const fs = require('fs');
const path = require('path');

exports.addProject = async (req, res) => {
  try {
    const {
      title,
      category,
      isFetured,
      description,
      program_title,
      banner_description,
      featuredImage,
      Image,
      galleryImages,
      tabs
    } = req.body;
    var slug = title.replace(" ", "-").toLowerCase();

    const checkProject = await Project.find({ slug: { $regex: `^${slug}(-[0-9]*)?$` } });
    if (checkProject.length > 0) {

      const slugNumbers = checkProject.map(loc => {
        const match = loc.slug.match(/-(\d+)$/);
        return match ? parseInt(match[1], 10) : 1;
      });

      const maxNumber = Math.max(...slugNumbers);
      slug = `${slug}-${maxNumber + 1}`;
    }
    const program = new Project({
      title,
      slug,
      category,
      isFetured,
      description,
      program_title,
      banner_description,
      featuredImage,
      Image,
      galleryImages,
      tabs
    });
    const savedProgram = await program.save();

    res.status(201).json({
      success: true,
      message: 'Program added successfully',
      data: savedProgram
    });
  } catch (error) {
    console.error('Error adding program:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while adding program',
      error: error.message
    });
  }
};

exports.projectsList = async (req, res) => {
  try {
    const projects = await Project.find().sort({ created_at: -1 });
    res.status(200).json(projects);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching projects' });
  }
};
exports.projectsFeaturedList = async (req, res) => {
  try {
    const projects = await Project.find({ isFetured: true }).sort({ priority: 1 });
    res.status(200).json(projects);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching projects' });
  }
};

exports.getProject = async (req, res) => {
  const { id } = req.params;
  try {
    const project = await Project.findById(id);
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
    res.status(200).json(project);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching project' });
  }
};

exports.getProjectBySlug = async (req, res) => {
  const { slug } = req.params;
  try {
    const project = await Project.findOne({ slug: slug });
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
    res.status(200).json(project);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching project' });
  }
};

exports.deleteProject = async (req, res) => {
  try {

    const { id } = req.params;

    const project = await Project.findById(id);
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    const deletedProject = await Project.findByIdAndDelete(id);
    if (!deletedProject) {
      return res.status(404).json({ message: 'project not found' });
    }

    const fs = require('fs');
    // project.galleryImages.forEach(imagePath => {
    //   fs.unlink(`./public${imagePath}`, err => {
    //     if (err) console.error('Failed to delete image:', imagePath);
    //   });
    // });

    // fs.unlink(`./public${project.featuredImage}`, err => {
    //   if (err) console.error('Failed to delete image:', imagePath);
    // });

    res.status(200).json({ message: 'Project deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete project' });
  }
};

exports.removeImage = async (req, res) => {
  const { projectId, imageName } = req.body;

  try {
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
    let updatedData = {};

    if (project.galleryImages.includes(imageName)) {
      updatedData.galleryImages = project.galleryImages.filter(image => image !== imageName);
    } else if (project.featuredImage === imageName) {
      updatedData.featuredImage = null; // or ''
    } else {
      return res.status(404).json({ message: 'Image not found in Project' });
    }
    const updatedProject = await Project.findByIdAndUpdate(projectId, { $set: updatedData }, { new: true });
    if (!updatedProject) {
      return res.status(404).json({ message: 'Failed to update Project' });
    }
    const filePath = path.join(__dirname, '..', 'public', imageName);
    fs.unlink(filePath, (err) => {
      if (err) {
        return res.status(500).json({ message: 'Error deleting image from filesystem' });
      }
      res.status(200).json({ message: 'Image removed successfully', project: updatedProject });
    });
  } catch (error) {
    console.error('Error removing image:', error);
    res.status(500).json({ message: 'Error removing image', error });
  }
};
exports.updateProject = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      category,
      isFetured,
      description,
      program_title,
      banner_description,
      featuredImage,
      Image,
      galleryImages,
      tabs
    } = req.body;

    // Retrieve the current project from the database
    const project = await Project.findById(id);
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    // Create an updated data object with the new ProgramsSchema structure
    const updatedData = {
      title: title || project.title,
      category: category || project.category,
      isFetured: isFetured || project.isFetured,
      description: description || project.description,
      program_title: program_title || project.program_title,
      banner_description: banner_description || project.banner_description,
      featuredImage: featuredImage || project.featuredImage,
      Image: Image || project.Image,
      galleryImages: galleryImages || project.galleryImages,
      tabs: tabs || project.tabs
    };

    // Update the project in the database
    const updatedProject = await Project.findByIdAndUpdate(
      id,
      updatedData,
      { new: true, runValidators: true }
    );

    if (!updatedProject) {
      return res.status(404).json({ message: 'Failed to update project' });
    }

    res.status(200).json({
      success: true,
      message: 'Project updated successfully',
      project: updatedProject
    });

  } catch (error) {
    console.error('Error updating Project:', error);

    // Check if it's a validation error
    if (error.name === 'ValidationError') {
      const validationErrors = Object.keys(error.errors).map(key => ({
        field: key,
        message: error.errors[key].message
      }));
      console.error('Validation errors:', validationErrors);
      return res.status(400).json({
        success: false,
        message: 'Validation error',
        errors: validationErrors
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to update Project',
      error: error.message
    });
  }
};

exports.updateProjectFeatured = async (req, res) => {
  try {
    const { featuredProjects, homePageFeatured, detailPageFeatured } = req.body;

    if (featuredProjects && featuredProjects.length > 0) {

      const multipleProjectIds = await Promise.all(featuredProjects.map(project => project._id));

      await Project.updateMany({}, { $set: { isFeatured: false } });

      await Project.updateMany(
        { _id: { $in: multipleProjectIds } },
        { $set: { isFeatured: true } }
      );
    }

    if (homePageFeatured) {
      await Project.updateMany({}, { $set: { isHomePageFeatured: false } });

      await Project.updateOne(
        { _id: homePageFeatured._id },
        { $set: { isHomePageFeatured: true } }
      );
    }

    if (detailPageFeatured) {
      await Project.updateMany({}, { $set: { isDetailPageFeatured: false } });

      await Project.updateOne(
        { _id: detailPageFeatured._id },
        { $set: { isDetailPageFeatured: true } }
      );
    }

    res.status(200).json({ message: 'Feature projects updated successfully' });

  } catch (error) {
    console.error('Error updating Project:', error);
    res.status(500).json({ message: 'Failed to set featured projects' });
  }
};

exports.updateProjectPositions = async (req, res) => {
  try {
    console.log('Received updateProjectPositions request:', req.body);
    console.log('Request headers:', req.headers);
    console.log('Request method:', req.method);
    
    const { positions } = req.body;

    if (!positions || !Array.isArray(positions)) {
      console.log('Invalid positions data received:', positions);
      return res.status(400).json({ message: 'Invalid positions data' });
    }

    if (positions.length === 0) {
      console.log('Empty positions array received');
      return res.status(400).json({ message: 'Positions array cannot be empty' });
    }

    console.log('Processing positions:', positions);
    
    // Validate MongoDB ObjectIds
    const mongoose = require('mongoose');
    const validIds = positions.filter(({ id }) => mongoose.Types.ObjectId.isValid(id));
    const invalidIds = positions.filter(({ id }) => !mongoose.Types.ObjectId.isValid(id));
    
    if (invalidIds.length > 0) {
      console.log('Invalid ObjectIds found:', invalidIds);
      return res.status(400).json({ message: 'Invalid project IDs provided' });
    }
    
    const updatePromises = positions.map(({ id, position }) => {
      console.log(`Updating project ${id} with priority ${position}`);
      console.log(`Query: { _id: "${id}" }`);
      console.log(`Update: { $set: { priority: "${position.toString()}" } }`);
      return Project.updateOne(
        { _id: id },
        { $set: { priority: position.toString() } }
      );
    });

    const results = await Promise.all(updatePromises);
    console.log('Update results:', results);

    // Check if all updates were successful
    const failedUpdates = results.filter(result => result.matchedCount === 0 || result.modifiedCount === 0);
    if (failedUpdates.length > 0) {
      console.log('Some updates failed:', failedUpdates);
      return res.status(500).json({ 
        message: 'Some project positions could not be updated',
        failedUpdates: failedUpdates.length
      });
    }

    res.status(200).json({ 
      message: 'Project positions updated successfully',
      updatedCount: results.length
    });
  } catch (error) {
    console.error('Error updating project positions:', error);
    res.status(500).json({ 
      message: 'Failed to update project positions',
      error: error.message 
    });
  }
};

exports.getFeaturedProjects = async (req, res) => {
  try {
    const projects = await Project.find({ isFeatured: true })
      .sort({
        priority: 1
      });

    res.status(200).json(projects);
  } catch (error) {
    console.error('Error fetching featured projects:', error);
    res.status(500).json({ message: 'Failed to fetch featured projects' });
  }
};