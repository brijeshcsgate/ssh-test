const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const adminRouter = require('./routes/admin');
const projectRouter = require('./routes/project');
const categoryRoutes = require('./routes/category');

const menuRouter = require('./routes/menu');
const app = express();
const connectDB = require("./db/config");
require('dotenv').config();
const startSitemapCron = require("./routes/sitemaps");
const PORT = process.env.PORT || 5000; 

connectDB();
app.use(cors({
    origin: ['http://192.168.1.4:4173','http://localhost:3000', 'http://localhost:4173'], 
    credentials: true 
}));
app.use(bodyParser.json({ limit: '20mb' }));
app.use(bodyParser.urlencoded({ limit: '20mb', extended: true })); 
app.use(express.static('public'));
app.use(express.json());

// Add request logging middleware
app.use((req, res, next) => {
  console.log(`${req.method} ${req.path}`, {
    body: req.body,
    headers: req.headers,
    cookies: req.cookies,
    contentType: req.get('Content-Type'),
    contentLength: req.get('Content-Length'),
    url: req.url,
    originalUrl: req.originalUrl,
    method: req.method,
    path: req.path
  });
  next();
});

app.use('/api/admin', adminRouter);
app.use('/api/admin', projectRouter);
app.use('/api/admin', menuRouter);
app.use("/api/admin/categories", categoryRoutes);
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
